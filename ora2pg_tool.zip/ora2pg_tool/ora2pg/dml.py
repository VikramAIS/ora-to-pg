"""Apply the target column catalog to INSERT / UPDATE statements.

* renames tables/columns per config
* wraps every character expression in ``left(expr, <column length>)`` so an
  Oracle VARCHAR2 that silently fitted does not blow up with
  "value too long for type character varying(n)".
"""

from __future__ import annotations

import re
from typing import List

from .config import ColumnInfo, Config
from .logging_calls import line_indent, reindent
from .sqlutil import find_matching_paren, split_top_level

_INSERT_RE = re.compile(r"\bINSERT\s+INTO\s+(?P<table>[\w$#.]+)\s*(?=\()", re.I)
_UPDATE_RE = re.compile(r"\bUPDATE\s+(?P<table>[\w$#.]+)\s+SET\b", re.I)
_SET_END_RE = re.compile(r"\b(WHERE|RETURNING|FROM)\b", re.I)


def transform_dml(cfg: Config, masked: str, notes) -> str:
    masked = _rename_tables(cfg, masked)
    if not cfg.wrap_with_left:
        return masked
    masked = _wrap_inserts(cfg, masked, notes)
    masked = _wrap_updates(cfg, masked)
    return masked


def _rename_tables(cfg: Config, masked: str) -> str:
    for src, dst in cfg.table_renames.items():
        masked = re.sub(rf"\b{re.escape(src)}\b", dst, masked, flags=re.I)
    for src, dst in cfg.column_renames.items():
        masked = re.sub(rf"\b{re.escape(src)}\b", dst, masked, flags=re.I)
    return masked


def _wrap_inserts(cfg: Config, masked: str, notes) -> str:
    pos = 0
    while True:
        m = _INSERT_RE.search(masked, pos)
        if not m:
            return masked
        col_open = masked.index("(", m.end() - 1)
        col_close = find_matching_paren(masked, col_open)
        if col_close == -1:
            return masked
        cols = [c.strip().split(".")[-1].lower()
                for c in split_top_level(masked[col_open + 1:col_close])]

        after = masked[col_close + 1:]
        vm = re.match(r"\s*VALUES\s*", after, re.I)
        if not vm:
            notes.add("INFO", "insert-select", m.group("table"),
                      "INSERT ... SELECT - length truncation not applied automatically.")
            pos = col_close + 1
            continue

        catalog = cfg.table_columns(m.group("table"))
        if not catalog:
            notes.add("WARN", "unknown-table", m.group("table"),
                      "Table is not in the column catalog - no left() truncation applied.")
            pos = col_close + 1
            continue

        val_open = col_close + 1 + vm.end()
        val_close = find_matching_paren(masked, val_open)
        if val_close == -1 or masked[val_open] != "(":
            pos = col_close + 1
            continue
        values = split_top_level(masked[val_open + 1:val_close])
        if len(values) != len(cols):
            notes.add("WARN", "insert-arity", m.group("table"),
                      "Column/value count mismatch - left() truncation skipped.")
            pos = val_close + 1
            continue

        new_values = [_wrap_value(cfg, catalog.get(col), val)
                      for col, val in zip(cols, values)]
        pad = line_indent(masked, m.start())
        body = (",\n" + " " * (pad + 4)).join(reindent(v, pad + 4) for v in new_values)
        rebuilt = "\n" + " " * (pad + 4) + body + "\n" + " " * pad
        masked = masked[:val_open + 1] + rebuilt + masked[val_close:]
        pos = val_open + len(rebuilt) + 2


def _wrap_updates(cfg: Config, masked: str) -> str:
    pos = 0
    while True:
        m = _UPDATE_RE.search(masked, pos)
        if not m:
            return masked
        catalog = cfg.table_columns(m.group("table"))
        if not catalog:
            pos = m.end()
            continue
        tail = masked[m.end():]
        end_m = _SET_END_RE.search(tail)
        set_end = m.end() + (end_m.start() if end_m else _statement_end(tail))
        assignments = split_top_level(masked[m.end():set_end])
        rebuilt: List[str] = []
        for assign in assignments:
            am = re.match(r"^([\w$#.]+)\s*=\s*(.+)$", assign.strip(), re.S)
            if not am:
                rebuilt.append(assign)
                continue
            col = am.group(1).split(".")[-1].lower()
            rebuilt.append(f"{am.group(1)} = {_wrap_value(cfg, catalog.get(col), am.group(2))}")
        pad = line_indent(masked, m.start())
        new_set = ("\n" + " " * (pad + 4)
                   + (",\n" + " " * (pad + 4)).join(rebuilt) + "\n" + " " * pad)
        masked = masked[:m.end()] + new_set + masked[set_end:]
        pos = m.end() + len(new_set)


def _statement_end(text: str) -> int:
    depth = 0
    for i, c in enumerate(text):
        if c == "(":
            depth += 1
        elif c == ")":
            if depth == 0:
                return i
            depth -= 1
        elif c == ";" and depth == 0:
            return i
    return len(text)


def _wrap_value(cfg: Config, col: ColumnInfo | None, expr: str) -> str:
    e = expr.strip()
    if col is None or not col.is_char or not e:
        return e
    low = e.lower()
    if any(low.startswith(p) for p in cfg.skip_wrap_prefixes):
        return e
    if low in ("null", "default"):
        return e
    return f"left({e}, {col.length})"
