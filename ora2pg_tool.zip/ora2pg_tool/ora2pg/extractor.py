"""Pull DDL out of Oracle (or read it from a folder of .sql files).

Input list format - one entry per line, blank lines and ``#`` comments ignored::

    CPDQ999.CPDQ_DATA_QUALITY_QUERY_PKG              -> whole package body
    CPDQ999.CPDQ_DATA_QUALITY_QUERY_PKG.STORE_ONE_COLUMN_DETAIL  -> one subprogram
    CPDQ999.MY_STANDALONE_PROC                       -> standalone procedure
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional


@dataclass
class SourceObject:
    schema: str
    name: str            # package or standalone object name
    subprogram: Optional[str]  # only convert this one, when given
    object_type: str     # PACKAGE BODY | PROCEDURE | FUNCTION
    ddl: str

    @property
    def key(self) -> str:
        return ".".join(x for x in (self.schema, self.name, self.subprogram) if x)


def parse_proc_list(path: Path) -> List[tuple]:
    entries = []
    for raw in Path(path).read_text(encoding="utf-8").splitlines():
        line = raw.split("#", 1)[0].strip().rstrip(";")
        if not line:
            continue
        parts = [p.strip().strip('"') for p in line.split(".") if p.strip()]
        if len(parts) == 2:
            entries.append((parts[0].upper(), parts[1].upper(), None))
        elif len(parts) >= 3:
            entries.append((parts[0].upper(), parts[1].upper(), parts[2].upper()))
        else:
            raise ValueError(f"Cannot parse entry {raw!r}; expected SCHEMA.OBJECT[.SUBPROGRAM]")
    return entries


# --------------------------------------------------------------------- Oracle
_TYPE_SQL = """
    SELECT object_type
      FROM all_objects
     WHERE owner = :owner
       AND object_name = :name
       AND object_type IN ('PACKAGE BODY', 'PACKAGE', 'PROCEDURE', 'FUNCTION')
     ORDER BY CASE object_type
                WHEN 'PACKAGE BODY' THEN 1
                WHEN 'PROCEDURE'    THEN 2
                WHEN 'FUNCTION'     THEN 3
                ELSE 4
              END
"""

_SOURCE_SQL = """
    SELECT text
      FROM all_source
     WHERE owner = :owner
       AND name  = :name
       AND type  = :type
     ORDER BY line
"""


class OracleExtractor:
    """Reads ALL_SOURCE. Needs only SELECT on ALL_SOURCE / ALL_OBJECTS."""

    def __init__(self, dsn: str, user: str, password: str, thick_lib: Optional[str] = None):
        import oracledb  # imported lazily so offline runs need no driver

        if thick_lib:
            oracledb.init_oracle_client(lib_dir=thick_lib)
        self._db = oracledb
        self.conn = oracledb.connect(user=user, password=password, dsn=dsn)

    def close(self) -> None:
        try:
            self.conn.close()
        except Exception:
            pass

    def object_type(self, owner: str, name: str) -> Optional[str]:
        with self.conn.cursor() as cur:
            cur.execute(_TYPE_SQL, owner=owner, name=name)
            row = cur.fetchone()
        return row[0] if row else None

    def fetch(self, owner: str, name: str, subprogram: Optional[str]) -> SourceObject:
        otype = self.object_type(owner, name)
        if otype is None:
            raise LookupError(f"{owner}.{name} not found in ALL_OBJECTS")
        if otype == "PACKAGE":
            otype = "PACKAGE BODY"
        with self.conn.cursor() as cur:
            cur.execute(_SOURCE_SQL, owner=owner, name=name, type=otype)
            ddl = "".join(r[0] for r in cur)
        if not ddl.strip():
            raise LookupError(f"No source rows for {owner}.{name} ({otype})")
        ddl = _ensure_create_prefix(ddl)
        return SourceObject(owner, name, subprogram, otype, ddl)


def _ensure_create_prefix(ddl: str) -> str:
    """ALL_SOURCE starts at ``PACKAGE BODY x`` - make it a runnable statement."""
    head = ddl.lstrip()
    if re.match(r"CREATE\s+(OR\s+REPLACE\s+)?", head, re.I):
        return ddl
    return f"CREATE OR REPLACE {head}"


# ---------------------------------------------------------------------- files
def fetch_from_dir(source_dir: Path, owner: str, name: str,
                   subprogram: Optional[str]) -> SourceObject:
    """Offline mode: look for ``SCHEMA.OBJECT.sql`` (or ``OBJECT.sql``)."""
    candidates = [
        source_dir / f"{owner}.{name}.sql",
        source_dir / f"{owner.lower()}.{name.lower()}.sql",
        source_dir / f"{name}.sql",
        source_dir / f"{name.lower()}.sql",
        source_dir / f"{owner}/{name}.sql",
        source_dir / f"{owner.lower()}/{name.lower()}.sql",
    ]
    for c in candidates:
        if c.exists():
            ddl = c.read_text(encoding="utf-8", errors="replace")
            otype = "PACKAGE BODY" if re.search(r"\bPACKAGE\s+BODY\b", ddl, re.I) else (
                "FUNCTION" if re.search(r"\bCREATE\s+(OR\s+REPLACE\s+)?FUNCTION\b", ddl, re.I)
                else "PROCEDURE"
            )
            return SourceObject(owner, name, subprogram, otype, ddl)
    raise FileNotFoundError(f"No .sql file for {owner}.{name} under {source_dir}")
