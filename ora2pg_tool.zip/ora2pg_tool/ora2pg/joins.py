"""Rewrite Oracle's ``(+)`` outer-join syntax as ANSI LEFT/RIGHT OUTER JOIN.

The rewrite is deliberately conservative: anything ambiguous (OR'ed outer
predicates, more than one optional alias in a single predicate, a cyclic join
graph) is left untouched and reported so a human decides.
"""

from __future__ import annotations

import re
from typing import Dict, List, Optional, Set, Tuple

from .sqlutil import find_matching_paren, split_top_level, split_top_level_keyword

_FROM_END = re.compile(
    r"\b(WHERE|GROUP\s+BY|HAVING|ORDER\s+BY|CONNECT\s+BY|START\s+WITH|UNION|EXCEPT|MINUS|"
    r"INTERSECT|LOOP|RETURNING|FOR\s+UPDATE|LIMIT|OFFSET)\b",
    re.I,
)
_WHERE_END = re.compile(
    r"\b(GROUP\s+BY|HAVING|ORDER\s+BY|CONNECT\s+BY|START\s+WITH|UNION|EXCEPT|MINUS|"
    r"INTERSECT|LOOP|RETURNING|FOR\s+UPDATE|LIMIT|OFFSET)\b",
    re.I,
)
_PLUS_RE = re.compile(r"\(\s*\+\s*\)")
_QUALIFIED_RE = re.compile(r"\b([A-Za-z_][\w$#]*)\s*\.\s*[A-Za-z_][\w$#]*")
# alias.column(+)  - also matches when the column sits inside a function call.
_OPTIONAL_RE = re.compile(
    r"\b([A-Za-z_][\w$#]*)\s*\.\s*[A-Za-z_][\w$#]*\s*\(\s*\+\s*\)")


_ALIAS_KEYWORDS = {"WHERE", "GROUP", "ORDER", "HAVING", "CONNECT", "START", "UNION",
                   "INTERSECT", "EXCEPT", "MINUS", "ON", "USING", "AS"}


def _parse_from_item(item: str) -> Optional[Tuple[str, str]]:
    """Return ``(alias, original_text)`` for one FROM-list entry.

    Handles ``TABLE``, ``SCHEMA.TABLE a``, ``TABLE AS a``, ``TABLE@dblink a``,
    ``TABLE PARTITION (p) a`` and ``(SELECT ...) a``.
    """
    text = item.strip()
    if not text:
        return None

    if text.startswith("("):
        close = find_matching_paren(text, 0)
        if close == -1:
            return None
        alias = _trailing_alias(text[close + 1:])
        return (alias, text) if alias else None

    m = re.match(r'^("?[\w$#]+"?(?:\s*\.\s*"?[\w$#]+"?)*(?:@[\w$#.]+)?)(.*)$', text, re.S)
    if not m:
        return None
    table, rest = m.group(1), m.group(2).strip()

    # Skip PARTITION (...) / SUBPARTITION (...) / SAMPLE (...) qualifiers.
    rest = re.sub(r"^(?:PARTITION|SUBPARTITION|SAMPLE)\b", "", rest, flags=re.I).strip()
    while rest.startswith("("):
        close = find_matching_paren(rest, 0)
        if close == -1:
            return None
        rest = rest[close + 1:].strip()

    alias = _trailing_alias(rest) or table.split(".")[-1].strip().strip('"')
    return alias.lower(), text


def _trailing_alias(rest: str) -> Optional[str]:
    rest = rest.strip()
    if not rest:
        return None
    rest = re.sub(r"^AS\b", "", rest, flags=re.I).strip()
    m = re.match(r'^"?([A-Za-z_][\w$#]*)"?\s*$', rest)
    if not m or m.group(1).upper() in _ALIAS_KEYWORDS:
        return None
    return m.group(1).lower()


def _unwrap(cond: str) -> List[str]:
    """Strip redundant surrounding parentheses and re-split on AND.

    ``(a.x(+) = b.x AND a.y(+) = b.y)`` arrives as one conjunct because the
    top-level split ignores everything inside parentheses.
    """
    text = cond.strip()
    while (text.startswith("(") and text.endswith(")")
           and find_matching_paren(text, 0) == len(text) - 1):
        text = text[1:-1].strip()
    parts = split_top_level_keyword(text, "AND")
    if len(parts) == 1:
        return [text]
    out: List[str] = []
    for p in parts:
        out.extend(_unwrap(p))
    return out


def convert_outer_joins(masked: str, notes) -> str:
    if not _PLUS_RE.search(masked):
        return masked

    out = masked
    cursor = 0
    while True:
        region = _next_region(out, cursor)
        if region is None:
            return out
        kw_start, f_start, f_end, w_start, w_end = region
        rewritten = _rewrite(out[f_start:f_end], out[w_start:w_end], notes)
        if rewritten is None:
            # Leave the statement exactly as it was and move past it. The review
            # report and the (+) pattern rule keep it visible.
            cursor = w_end
            continue
        new_from, new_where = rewritten
        where_sql = f"\n     WHERE {new_where}" if new_where.strip() else ""
        replacement = new_from + where_sql
        head = out[:kw_start].rstrip()
        out = head + replacement + out[w_end:]
        cursor = len(head) + len(replacement)


def _next_region(masked: str, start: int) -> Optional[Tuple[int, int, int, int, int]]:
    """Locate the FROM/WHERE spans of the next SELECT whose WHERE has a ``(+)``."""
    for m in re.finditer(r"\bFROM\b", masked, re.I):
        if m.start() < start:
            continue
        f_start = m.end()
        tail = masked[f_start:]
        fm = _bounded_search(_FROM_END, tail)
        if not fm or not fm.group(1).upper().startswith("WHERE"):
            continue
        f_end = f_start + fm.start()
        w_start = f_start + fm.end()
        wm = _bounded_search(_WHERE_END, masked[w_start:])
        w_end = w_start + (wm.start() if wm else _clause_end(masked[w_start:]))
        if _PLUS_RE.search(masked[w_start:w_end]):
            return m.start(), f_start, f_end, w_start, w_end
    return None


def _bounded_search(pattern: re.Pattern, text: str) -> Optional[re.Match]:
    """First match at paren depth 0, stopping at a closing paren or ``;``."""
    depth = 0
    i = 0
    while i < len(text):
        c = text[i]
        if c == "(":
            depth += 1
        elif c == ")":
            if depth == 0:
                return None
            depth -= 1
        elif depth == 0:
            if c == ";":
                return None
            m = pattern.match(text, i)
            if m:
                return m
        i += 1
    return None


def _clause_end(text: str) -> int:
    depth = 0
    for i, c in enumerate(text):
        if c == "(":
            depth += 1
        elif c == ")":
            if depth == 0:
                return i
            depth -= 1
        elif c == ";" and depth == 0:
            return i
    return len(text)


def _rewrite(from_clause: str, where_clause: str, notes) -> Optional[Tuple[str, str]]:
    items = split_top_level(from_clause, ",")
    if re.search(r"\b(LEFT|RIGHT|FULL|INNER|CROSS|NATURAL|JOIN)\b", from_clause, re.I):
        notes.add("ERROR", "outer-join", from_clause.strip()[:120],
                  "FROM clause mixes ANSI JOIN syntax with Oracle (+) - rewrite by hand.")
        return None
    if len(items) < 2:
        notes.add("ERROR", "outer-join", from_clause.strip()[:120],
                  "(+) found but the FROM clause has only one item - the outer join probably "
                  "spans a subquery; rewrite by hand.")
        return None

    aliases: Dict[str, str] = {}
    order: List[str] = []
    for item in items:
        parsed = _parse_from_item(item)
        if parsed is None:
            notes.add("ERROR", "outer-join", item.strip()[:120],
                      "Could not determine the alias of this FROM item, so the (+) joins in "
                      "this statement were left as-is.")
            return None
        alias, text = parsed
        aliases[alias] = text
        order.append(alias)

    conjuncts: List[str] = []
    for raw in split_top_level_keyword(where_clause, "AND"):
        conjuncts.extend(_unwrap(raw))

    join_conds: Dict[str, List[str]] = {}
    dependencies: Dict[str, Set[str]] = {}
    residual: List[str] = []

    for cond in conjuncts:
        if not _PLUS_RE.search(cond):
            residual.append(cond)
            continue
        if re.search(r"\bOR\b", cond, re.I):
            notes.add("ERROR", "outer-join", cond.strip()[:120],
                      "(+) inside an OR predicate - Oracle rejects this too (ORA-01719); "
                      "rewrite the predicate as an explicit LEFT OUTER JOIN.")
            return None
        optional = {m.group(1).lower() for m in _OPTIONAL_RE.finditer(cond)}
        if len(optional) > 1:
            notes.add("ERROR", "outer-join", cond.strip()[:120],
                      f"Predicate outer-joins more than one table ({', '.join(sorted(optional))}) "
                      "- Oracle rejects this too (ORA-01468).")
            return None
        if not optional:
            notes.add("ERROR", "outer-join", cond.strip()[:120],
                      "(+) is attached to an unqualified column, so the optional table cannot "
                      "be identified. Qualify the column in Oracle, or rewrite by hand.")
            return None
        opt = optional.pop()
        if opt not in aliases:
            notes.add("ERROR", "outer-join", cond.strip()[:120],
                      f"Optional alias {opt!r} is not in the FROM clause "
                      f"(found: {', '.join(sorted(aliases))}).")
            return None
        clean = _PLUS_RE.sub("", cond).strip()
        join_conds.setdefault(opt, []).append(clean)
        others = {m.group(1).lower() for m in _QUALIFIED_RE.finditer(clean)} - {opt}
        dependencies.setdefault(opt, set()).update(others & set(aliases))

    if not join_conds:
        return None

    base = [a for a in order if a not in join_conds]
    if not base:
        notes.add("ERROR", "outer-join", from_clause.strip()[:120],
                  "Every table in the FROM clause is outer-joined, so there is no driving "
                  "table - rewrite by hand.")
        return None

    # CROSS JOIN, not a comma: a comma binds looser than JOIN, so with two or more
    # driving tables PostgreSQL would reject an ON clause that references the first
    # one ("invalid reference to FROM-clause entry").
    parts = [aliases[base[0]]]
    parts += [f"CROSS JOIN {aliases[a]}" for a in base[1:]]

    emitted = set(base)
    remaining = [a for a in order if a in join_conds]
    while remaining:
        progressed = False
        for alias in list(remaining):
            if dependencies.get(alias, set()) <= emitted:
                on = "\n              AND ".join(join_conds[alias])
                parts.append(f"LEFT OUTER JOIN {aliases[alias]}\n              ON {on}")
                emitted.add(alias)
                remaining.remove(alias)
                progressed = True
        if not progressed:
            break
    if remaining:
        notes.add("ERROR", "outer-join", ", ".join(remaining),
                  "Outer-join dependency cycle - rewrite these joins by hand.")
        return None

    notes.add("INFO", "outer-join", ", ".join(sorted(join_conds)),
              "Oracle (+) rewritten as LEFT OUTER JOIN - verify row counts against Oracle.")
    new_from = "\n      FROM " + "\n           ".join(parts)
    return new_from, "\n       AND ".join(c for c in residual if c.strip())
