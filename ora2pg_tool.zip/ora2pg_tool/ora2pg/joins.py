"""Rewrite Oracle's ``(+)`` outer-join syntax as ANSI LEFT/RIGHT OUTER JOIN.

The rewrite is deliberately conservative: anything ambiguous (OR'ed outer
predicates, more than one optional alias in a single predicate, a cyclic join
graph) is left untouched and reported so a human decides.
"""

from __future__ import annotations

import re
from typing import Dict, List, Optional, Set, Tuple

from .sqlutil import split_top_level, split_top_level_keyword

_FROM_END = re.compile(
    r"\b(WHERE|GROUP\s+BY|HAVING|ORDER\s+BY|CONNECT\s+BY|START\s+WITH|UNION|EXCEPT|MINUS|"
    r"INTERSECT|LOOP|RETURNING|FOR\s+UPDATE|LIMIT|OFFSET)\b",
    re.I,
)
_WHERE_END = re.compile(
    r"\b(GROUP\s+BY|HAVING|ORDER\s+BY|CONNECT\s+BY|START\s+WITH|UNION|EXCEPT|MINUS|"
    r"INTERSECT|LOOP|RETURNING|FOR\s+UPDATE|LIMIT|OFFSET)\b",
    re.I,
)
_ALIAS_RE = re.compile(r"^(?P<table>[\w$#.]+(?:\s*\([^)]*\))?)\s*(?:\bAS\b\s*)?(?P<alias>[\w$#]+)?$",
                       re.I | re.S)
_PLUS_RE = re.compile(r"\(\s*\+\s*\)")
_QUALIFIED_RE = re.compile(r"\b([A-Za-z_][\w$#]*)\s*\.\s*[A-Za-z_][\w$#]*")


def convert_outer_joins(masked: str, notes) -> str:
    if "(+)" not in masked.replace(" ", ""):
        return masked

    out = masked
    guard = 0
    while _PLUS_RE.search(out) and guard < 50:
        guard += 1
        region = _next_region(out)
        if region is None:
            break
        kw_start, f_start, f_end, w_start, w_end = region
        from_clause = out[f_start:f_end]
        where_clause = out[w_start:w_end]
        rewritten = _rewrite(from_clause, where_clause, notes)
        if rewritten is None:
            # Neutralise so the loop terminates; the review rule keeps the flag.
            out = out[:w_start] + _PLUS_RE.sub("/*(+)*/", where_clause) + out[w_end:]
            continue
        new_from, new_where = rewritten
        where_sql = f"\n     WHERE {new_where}" if new_where.strip() else ""
        out = out[:kw_start] + new_from + where_sql + out[w_end:]
    return out


def _next_region(masked: str) -> Optional[Tuple[int, int, int, int, int]]:
    """Locate the FROM/WHERE spans of the next SELECT whose WHERE has a ``(+)``."""
    for m in re.finditer(r"\bFROM\b", masked, re.I):
        f_start = m.end()
        tail = masked[f_start:]
        fm = _bounded_search(_FROM_END, tail)
        if not fm or not fm.group(1).upper().startswith("WHERE"):
            continue
        f_end = f_start + fm.start()
        w_start = f_start + fm.end()
        wm = _bounded_search(_WHERE_END, masked[w_start:])
        w_end = w_start + (wm.start() if wm else _clause_end(masked[w_start:]))
        if _PLUS_RE.search(masked[w_start:w_end]):
            return m.start(), f_start, f_end, w_start, w_end
    return None


def _bounded_search(pattern: re.Pattern, text: str) -> Optional[re.Match]:
    """First match at paren depth 0, stopping at a closing paren or ``;``."""
    depth = 0
    i = 0
    while i < len(text):
        c = text[i]
        if c == "(":
            depth += 1
        elif c == ")":
            if depth == 0:
                return None
            depth -= 1
        elif depth == 0:
            if c == ";":
                return None
            m = pattern.match(text, i)
            if m:
                return m
        i += 1
    return None


def _clause_end(text: str) -> int:
    depth = 0
    for i, c in enumerate(text):
        if c == "(":
            depth += 1
        elif c == ")":
            if depth == 0:
                return i
            depth -= 1
        elif c == ";" and depth == 0:
            return i
    return len(text)


def _rewrite(from_clause: str, where_clause: str, notes) -> Optional[Tuple[str, str]]:
    items = split_top_level(from_clause, ",")
    if len(items) < 2:
        notes.add("ERROR", "outer-join", from_clause.strip()[:120],
                  "(+) found but the FROM clause has a single item - rewrite by hand.")
        return None
    if re.search(r"\b(LEFT|RIGHT|FULL|INNER|JOIN)\b", from_clause, re.I):
        notes.add("ERROR", "outer-join", from_clause.strip()[:120],
                  "Mixed ANSI JOIN and (+) syntax - rewrite by hand.")
        return None

    aliases: Dict[str, str] = {}
    order: List[str] = []
    for item in items:
        am = _ALIAS_RE.match(item.strip())
        if not am:
            return None
        table = am.group("table").strip()
        alias = (am.group("alias") or table.split(".")[-1]).strip()
        aliases[alias.lower()] = item.strip()
        order.append(alias.lower())

    conjuncts = split_top_level_keyword(where_clause, "AND")
    join_conds: Dict[str, List[str]] = {}
    dependencies: Dict[str, Set[str]] = {}
    residual: List[str] = []

    for cond in conjuncts:
        if not _PLUS_RE.search(cond):
            residual.append(cond)
            continue
        if re.search(r"\bOR\b", cond, re.I):
            notes.add("ERROR", "outer-join", cond.strip()[:120],
                      "(+) inside an OR predicate cannot be mechanically rewritten.")
            return None
        optional = {m.group(1).lower()
                    for m in re.finditer(r"\b([A-Za-z_][\w$#]*)\s*\.\s*[A-Za-z_][\w$#]*\s*\(\s*\+\s*\)",
                                         cond)}
        if len(optional) != 1:
            notes.add("ERROR", "outer-join", cond.strip()[:120],
                      "Predicate marks zero or multiple optional tables with (+).")
            return None
        opt = optional.pop()
        if opt not in aliases:
            notes.add("ERROR", "outer-join", cond.strip()[:120],
                      f"Optional alias {opt!r} is not in the FROM clause.")
            return None
        clean = _PLUS_RE.sub("", cond).strip()
        join_conds.setdefault(opt, []).append(clean)
        others = {m.group(1).lower() for m in _QUALIFIED_RE.finditer(clean)} - {opt}
        dependencies.setdefault(opt, set()).update(others & set(aliases))

    if not join_conds:
        return None

    base = [a for a in order if a not in join_conds]
    if not base:
        notes.add("ERROR", "outer-join", from_clause.strip()[:120],
                  "Every table in the FROM clause is outer-joined - no driving table.")
        return None

    emitted = set(base)
    lines = [",\n           ".join(aliases[a] for a in base)]
    remaining = [a for a in order if a in join_conds]
    guard = 0
    while remaining and guard <= len(remaining) * len(remaining) + 1:
        guard += 1
        progressed = False
        for alias in list(remaining):
            if dependencies.get(alias, set()) <= emitted:
                on = "\n              AND ".join(join_conds[alias])
                lines.append(f"LEFT OUTER JOIN {aliases[alias]}\n              ON {on}")
                emitted.add(alias)
                remaining.remove(alias)
                progressed = True
        if not progressed:
            break
    if remaining:
        notes.add("ERROR", "outer-join", ", ".join(remaining),
                  "Outer-join dependency cycle - rewrite these joins by hand.")
        return None

    notes.add("INFO", "outer-join", ", ".join(sorted(join_conds)),
              "Oracle (+) rewritten as LEFT OUTER JOIN - verify row counts against Oracle.")
    new_from = "\n      FROM " + "\n           ".join(lines)
    return new_from, "\n       AND ".join(c for c in residual if c.strip())
