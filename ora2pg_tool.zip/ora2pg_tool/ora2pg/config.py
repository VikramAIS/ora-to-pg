"""Load and normalise config/mappings.yaml (plus an optional column CSV)."""

from __future__ import annotations

import csv
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml


@dataclass
class ColumnInfo:
    name: str
    type: str
    length: int = 0

    @property
    def is_char(self) -> bool:
        return self.length > 0 and re.search(r"char|text|string", self.type, re.I) is not None


@dataclass
class LogHandler:
    name: str
    oracle: List[str]
    pg_function: str
    oracle_args: List[str]
    pg_args: List[str]
    lengths: Dict[str, int] = field(default_factory=dict)
    enrich_message_in_handler: bool = False
    unknown_error_text: str = "Unknown PostgreSQL error"


@dataclass
class ReviewRule:
    pattern: re.Pattern
    severity: str
    note: str


class Config:
    def __init__(self, data: Dict[str, Any]):
        self.raw = data
        t = data.get("target", {})
        self.name_style: str = t.get("name_style", "package_prefix")
        self.schema_map: Dict[str, str] = {
            k.upper(): v for k, v in (t.get("schema_map") or {}).items()
        }
        self.object_overrides: Dict[str, str] = {
            k.upper(): v for k, v in (t.get("object_name_overrides") or {}).items()
        }
        self.known_packages = {str(p).upper() for p in (t.get("known_packages") or [])}
        self.package_constants: Dict[str, str] = {
            k.upper().replace(" ", ""): str(v)
            for k, v in (t.get("package_constants") or {}).items()
        }
        self.max_ident: int = int(t.get("max_identifier_length", 63))

        e = data.get("emit", {})
        self.language: str = e.get("language", "plpgsql")
        self.cost: int = int(e.get("cost", 100))
        self.volatility: str = e.get("volatility", "VOLATILE")
        self.parallel: str = e.get("parallel", "PARALLEL UNSAFE")
        self.body_delim: str = e.get("body_delimiter", "$BODY$")
        self.procedure_as: str = e.get("procedure_as", "function")
        self.uppercase_keywords: bool = bool(e.get("uppercase_keywords", True))
        self.emit_review_comments: bool = bool(e.get("emit_review_comments", True))

        d = data.get("datatypes", {})
        self.num_int_prec = int(d.get("number_precision_to_int", 9))
        self.num_bigint_prec = int(d.get("number_precision_to_bigint", 18))
        self.number_bare = d.get("number_bare", "numeric")
        self.keep_varchar_length = bool(d.get("keep_varchar_length", False))
        self.type_rules = [
            (re.compile(r["match"], re.I | re.S), r["replace"]) for r in (d.get("rules") or [])
        ]

        v = data.get("variable_types", {})
        self.var_name_wins = bool(v.get("name_overrides_declared_type", True))
        self.var_suffix_wins = bool(v.get("suffix_overrides_declared_type", False))
        self.var_by_name: Dict[str, str] = {
            k.lower(): val for k, val in (v.get("by_name") or {}).items()
        }
        self.var_by_suffix: Dict[str, str] = {
            k.lower(): val for k, val in (v.get("by_suffix") or {}).items()
        }
        self.var_renames: Dict[str, str] = {
            k.lower(): val for k, val in (v.get("renames") or {}).items()
        }

        lg = data.get("logging", {})
        dv = lg.get("diagnostics_vars") or {}
        self.diag = {
            "sqlstate": dv.get("sqlstate", "v_sqlstate"),
            "message": dv.get("message", "v_message"),
            "detail": dv.get("detail", "v_detail"),
            "hint": dv.get("hint", "v_hint"),
            "context": dv.get("context", "v_context"),
        }
        self.log_handlers: List[LogHandler] = [
            LogHandler(
                name=h["name"],
                oracle=[o.upper() for o in h["oracle"]],
                pg_function=h["pg_function"],
                oracle_args=h["oracle_args"],
                pg_args=h["pg_args"],
                lengths={k: int(x) for k, x in (h.get("lengths") or {}).items()},
                enrich_message_in_handler=bool(h.get("enrich_message_in_handler", False)),
                unknown_error_text=h.get("unknown_error_text", "Unknown PostgreSQL error"),
            )
            for h in (lg.get("handlers") or [])
        ]
        self.attribute_map: Dict[str, str] = {
            k.upper(): val for k, val in (lg.get("attribute_map") or {}).items()
        }

        b = data.get("builtins", {})
        self.builtin_calls: Dict[str, str] = {
            k.upper(): val for k, val in (b.get("calls") or {}).items()
        }
        self.builtin_tokens: Dict[str, str] = {
            k.upper(): val for k, val in (b.get("tokens") or {}).items()
        }

        dm = data.get("dml", {})
        self.wrap_with_left = bool(dm.get("wrap_char_columns_with_left", True))
        self.skip_wrap_prefixes = [p.lower() for p in (dm.get("skip_wrap_prefixes") or [])]

        self.columns: Dict[str, Dict[str, ColumnInfo]] = {}
        for tbl, cols in (data.get("columns") or {}).items():
            self.columns[tbl.lower()] = {
                c.lower(): ColumnInfo(c.lower(), (spec or {}).get("type", "text"),
                                      int((spec or {}).get("length", 0) or 0))
                for c, spec in (cols or {}).items()
            }

        self.table_renames = {k.lower(): v for k, v in (data.get("table_renames") or {}).items()}
        self.column_renames = {k.lower(): v for k, v in (data.get("column_renames") or {}).items()}

        self.review_rules = [
            ReviewRule(re.compile(r["match"], re.I), r.get("severity", "WARN"), r["note"])
            for r in (data.get("review_rules") or [])
        ]

    # ------------------------------------------------------------------ load
    @classmethod
    def load(cls, path: Path, columns_csv: Optional[Path] = None) -> "Config":
        data = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
        cfg = cls(data)
        if columns_csv and Path(columns_csv).exists():
            cfg.load_columns_csv(Path(columns_csv))
        return cfg

    def load_columns_csv(self, path: Path) -> None:
        """CSV columns: schema,table,column,data_type,udt_name,length,nullable."""
        with Path(path).open(newline="", encoding="utf-8-sig") as fh:
            for row in csv.DictReader(fh):
                row = {(k or "").strip().lower(): (v or "").strip() for k, v in row.items()}
                if not row.get("table") or not row.get("column"):
                    continue
                key = f"{row.get('schema', '').lower()}.{row['table'].lower()}".lstrip(".")
                length = int(row["length"]) if row.get("length", "").isdigit() else 0
                self.columns.setdefault(key, {})[row["column"].lower()] = ColumnInfo(
                    row["column"].lower(), row.get("udt_name") or row.get("data_type") or "text",
                    length,
                )

    # ------------------------------------------------------------- accessors
    def pg_schema(self, oracle_schema: str) -> str:
        return self.schema_map.get(oracle_schema.upper(), oracle_schema.lower())

    def table_columns(self, table: str) -> Dict[str, ColumnInfo]:
        t = table.lower()
        if t in self.columns:
            return self.columns[t]
        # tolerate an unqualified reference
        tail = t.split(".")[-1]
        for k, v in self.columns.items():
            if k.split(".")[-1] == tail:
                return v
        return {}
