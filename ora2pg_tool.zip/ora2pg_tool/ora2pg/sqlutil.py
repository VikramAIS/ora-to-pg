"""Tokenising and paren-aware text utilities shared by every transform."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable, List, Optional, Tuple

TOKEN_RE = re.compile(r"\x01\d+\x02|[A-Za-z_][A-Za-z0-9_$#]*|\d+(?:\.\d+)?|:=|\|\||[^\s]")

# Keywords re-capitalised at the very end so the output reads like the
# hand-written sample DDL.
# NOTE: deliberately excludes function names (left, coalesce, replace, cast,
# current_user, ...) so calls stay lower case like the hand-written sample DDL.
PG_KEYWORDS = {
    "ALL", "AND", "ANY", "AS", "ASC", "BEGIN", "BETWEEN", "BY", "CASE", "CLOSE",
    "CONSTANT", "CONTINUE", "CURSOR", "DECLARE", "DEFAULT", "DELETE", "DESC",
    "DIAGNOSTICS", "DISTINCT", "ELSE", "ELSIF", "END", "EXCEPT", "EXCEPTION",
    "EXECUTE", "EXISTS", "EXIT", "FETCH", "FOR", "FOREACH", "FROM", "GET",
    "GROUP", "HAVING", "IF", "IN", "INSERT", "INTERSECT", "INTO", "IS",
    "LANGUAGE", "LIKE", "LIMIT", "LOOP", "NOT", "NULL", "OFFSET", "ON", "OPEN",
    "OR", "ORDER", "OTHERS", "OUT", "PERFORM", "RAISE", "RETURN", "RETURNING",
    "REVERSE", "SELECT", "SET", "STACKED", "STRICT", "THEN", "TRUE", "FALSE",
    "UNION", "UPDATE", "USING", "VALUES", "WHEN", "WHERE", "WHILE", "WITH",
    # GET STACKED DIAGNOSTICS condition names
    "RETURNED_SQLSTATE", "MESSAGE_TEXT", "PG_EXCEPTION_DETAIL", "PG_EXCEPTION_HINT",
    "PG_EXCEPTION_CONTEXT", "ROW_COUNT", "SQLSTATE", "SQLERRM", "ERRCODE",
}

_JOIN_RE = re.compile(r"\b(left|right|full|inner|cross)(\s+outer)?\s+join\b", re.I)

_BLOCK_OPENERS = {"BEGIN", "IF", "LOOP", "CASE"}
_BLOCK_CLOSERS = {"IF", "LOOP", "CASE"}


@dataclass
class Token:
    text: str
    start: int
    end: int

    @property
    def up(self) -> str:
        return self.text.upper()


def tokenize(masked: str) -> List[Token]:
    return [Token(m.group(0), m.start(), m.end()) for m in TOKEN_RE.finditer(masked)]


def find_matching_paren(text: str, open_idx: int) -> int:
    """Index of the ``)`` matching the ``(`` at `open_idx` (-1 if unbalanced)."""
    depth = 0
    for i in range(open_idx, len(text)):
        c = text[i]
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
            if depth == 0:
                return i
    return -1


def split_top_level(text: str, sep: str = ",") -> List[str]:
    """Split on `sep` ignoring anything nested inside parentheses."""
    parts, depth, buf = [], 0, []
    for c in text:
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
        if c == sep and depth == 0:
            parts.append("".join(buf))
            buf = []
        else:
            buf.append(c)
    parts.append("".join(buf))
    return [p.strip() for p in parts]


def split_top_level_keyword(text: str, keyword: str) -> List[str]:
    """Split on a bare keyword (e.g. ``AND``) at paren depth 0."""
    pattern = re.compile(rf"\b{keyword}\b", re.I)
    parts, depth, last = [], 0, 0
    i = 0
    while i < len(text):
        c = text[i]
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
        elif depth == 0:
            m = pattern.match(text, i)
            if m:
                parts.append(text[last:i])
                last = m.end()
                i = m.end()
                continue
        i += 1
    parts.append(text[last:])
    return [p.strip() for p in parts if p.strip()]


def block_depths(tokens: List[Token]) -> Iterable[Tuple[int, Token, int, int]]:
    """Yield ``(index, token, depth_before, depth_after)`` for PL/SQL blocks.

    ``END IF`` / ``END LOOP`` / ``END CASE`` are consumed as a unit so a plain
    ``END`` unambiguously closes a ``BEGIN`` (or a subprogram).
    """
    depth = 0
    skip = -1
    for i, tok in enumerate(tokens):
        if i <= skip:
            continue
        up = tok.up
        before = depth
        if up == "END":
            nxt = tokens[i + 1].up if i + 1 < len(tokens) else ""
            depth -= 1
            if nxt in _BLOCK_CLOSERS:
                skip = i + 1
        elif up in _BLOCK_OPENERS:
            depth += 1
        yield i, tok, before, depth


def index_of_semicolon(tokens: List[Token], from_idx: int) -> int:
    for i in range(from_idx, len(tokens)):
        if tokens[i].text == ";":
            return i
    return len(tokens) - 1


def uppercase_keywords(masked: str) -> str:
    def repl(m: re.Match) -> str:
        w = m.group(0)
        return w.upper() if w.upper() in PG_KEYWORDS else w

    masked = re.sub(r"[A-Za-z_][A-Za-z0-9_$#]*", repl, masked)
    return _JOIN_RE.sub(lambda m: m.group(0).upper(), masked)


def lower_identifiers(masked: str) -> str:
    """PostgreSQL folds unquoted identifiers to lower case - do it explicitly so
    the generated source matches what the catalog will actually contain."""
    return re.sub(r"[A-Za-z_][A-Za-z0-9_$#]*", lambda m: m.group(0).lower(), masked)


def dedent_block(text: str) -> str:
    lines = [ln.rstrip() for ln in text.splitlines()]
    body = [ln for ln in lines if ln.strip()]
    if not body:
        return ""
    pad = min(len(ln) - len(ln.lstrip()) for ln in body)
    return "\n".join(ln[pad:] if ln.strip() else "" for ln in lines).strip("\n")


def indent_block(text: str, spaces: int) -> str:
    pad = " " * spaces
    return "\n".join(pad + ln if ln.strip() else "" for ln in text.splitlines())


def statement_starts_here(masked: str, pos: int) -> bool:
    """True when position `pos` begins a new statement (so a call can become
    ``PERFORM``)."""
    head = masked[:pos].rstrip()
    if not head:
        return True
    if head[-1] in ";":
        return True
    m = re.search(r"([A-Za-z_][A-Za-z0-9_$#]*)\s*$", head)
    return bool(m) and m.group(1).upper() in {
        "BEGIN", "THEN", "ELSE", "LOOP", "DECLARE", "EXCEPTION",
    }


def normalize_name(name: str) -> str:
    return re.sub(r'"', "", name).strip().lower()


def qualified_tail(name: str, parts: int) -> Optional[str]:
    bits = name.split(".")
    return ".".join(bits[-parts:]) if len(bits) >= parts else None
