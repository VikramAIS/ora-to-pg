"""Oracle PL/SQL -> PostgreSQL PL/pgSQL converter."""

__version__ = "1.0.0"
