"""Replace Oracle logging-package calls with your PostgreSQL logging functions.

Oracle::

    CPDC999.Rmdpk_Error_Log_Util.Log_Error(schemaName, procName, 'Inserting report lines',
        'Error while trying to insert data for material ' || sCur.CODE ||
        ' into PROCEDURE_LINE table', SQLCODE, SQLERRM);

PostgreSQL::

    PERFORM cpdc999.rmdpk_error_log_util_log_error
    (
        schemaname,
        procname,
        'Inserting report lines',
        left(concat_ws(' | ', 'Error while trying ...', nullif(v_detail, ''),
                       nullif(v_hint, ''), nullif(v_context, '')), 2000),
        v_sqlstate,
        left(coalesce(nullif(v_message, ''), 'Unknown PostgreSQL error'), 1000)
    );
"""

from __future__ import annotations

import re
from typing import List, Optional

from .config import Config, LogHandler
from .masking import Masker
from .sqlutil import find_matching_paren, split_top_level, statement_starts_here

_CALL_RE = re.compile(r"\b([A-Za-z_][\w$#]*(?:\s*\.\s*[A-Za-z_][\w$#]*)+)\s*\(")

# GET STACKED DIAGNOSTICS block injected at the top of an exception handler.
DIAG_TEMPLATE = """GET STACKED DIAGNOSTICS
    {sqlstate} = RETURNED_SQLSTATE,
    {message}  = MESSAGE_TEXT,
    {detail}   = PG_EXCEPTION_DETAIL,
    {hint}     = PG_EXCEPTION_HINT,
    {context}  = PG_EXCEPTION_CONTEXT;"""


def reindent(text: str, pad: int) -> str:
    """Re-indent every line except the first to `pad`, preserving relative depth."""
    lines = text.splitlines()
    if len(lines) < 2:
        return text
    rest = lines[1:]
    body = [ln for ln in rest if ln.strip()]
    base = min((len(ln) - len(ln.lstrip()) for ln in body), default=0)
    return lines[0] + "\n" + "\n".join(
        " " * pad + ln[base:] if ln.strip() else "" for ln in rest)


def line_indent(text: str, pos: int) -> int:
    start = text.rfind("\n", 0, pos) + 1
    prefix = text[start:pos]
    return len(prefix) if not prefix.strip() else len(prefix) - len(prefix.lstrip())


def matches_handler(cfg: Config, dotted: str) -> Optional[LogHandler]:
    norm = re.sub(r"\s+", "", dotted).upper()
    parts = norm.split(".")
    for handler in cfg.log_handlers:
        for pattern in handler.oracle:
            p = pattern.split(".")
            if len(parts) >= len(p) and parts[-len(p):] == p:
                return handler
    return None


def is_logging_call(cfg: Config, text: str) -> bool:
    return any(matches_handler(cfg, m.group(1)) is not None for m in _CALL_RE.finditer(text))


def transform_logging_calls(cfg: Config, masked: str, masker: Masker, notes) -> str:
    """Rewrite every configured logging call found in `masked`."""
    pos = 0
    out = masked
    while True:
        m = _CALL_RE.search(out, pos)
        if not m:
            return out
        handler = matches_handler(cfg, m.group(1))
        if handler is None:
            pos = m.end()
            continue
        close = find_matching_paren(out, m.end() - 1)
        if close == -1:
            pos = m.end()
            continue
        args = [a for a in split_top_level(out[m.end():close])]
        replacement = _build_call(cfg, handler, args, masker)
        prefix = "PERFORM " if statement_starts_here(out, m.start()) else ""
        new_text = reindent(prefix + replacement, line_indent(out, m.start()))
        notes.add("INFO", "logging",
                  re.sub(r"\s+", " ", masker.unmask(out[m.start():close + 1]))[:120],
                  f"Mapped to {handler.pg_function}.")
        out = out[:m.start()] + new_text + out[close + 1:]
        pos = m.start() + len(new_text)


def _build_call(cfg: Config, handler: LogHandler, args: List[str],
                masker: Masker) -> str:
    named = {}
    for i, key in enumerate(handler.oracle_args):
        named[key] = args[i].strip() if i < len(args) else ""

    # Oracle SQLCODE / SQLERRM -> PostgreSQL stacked diagnostics.
    for key, value in list(named.items()):
        named[key] = _map_attributes(cfg, value)

    # Enrich the message only where the original call actually carried error
    # information, i.e. it sat inside an exception handler.
    diag_vars = set(cfg.diag.values())
    in_handler = any(
        any(re.search(rf"\b{re.escape(v)}\b", expr) for v in diag_vars)
        for expr in named.values()
    )

    rendered: List[str] = []
    for key in handler.pg_args:
        expr = named.get(key, "") or "NULL"
        length = handler.lengths.get(key, 0)

        if key == "message":
            expr = _message_expr(cfg, handler, expr, masker, in_handler, length)
        elif key == "errormessage":
            expr = _error_message_expr(handler, expr, masker, length)
        elif length:
            expr = _wrap_left(expr, length)
        rendered.append(expr)

    body = ",\n    ".join(reindent(r, 4) for r in rendered)
    return f"{handler.pg_function}\n(\n    {body}\n)"


def _map_attributes(cfg: Config, expr: str) -> str:
    for attr, var in cfg.attribute_map.items():
        expr = re.sub(rf"\b{re.escape(attr)}\b", var, expr, flags=re.I)
    return expr.strip()


def _message_expr(cfg: Config, handler: LogHandler, expr: str, masker: Masker,
                  in_handler: bool, length: int) -> str:
    if handler.enrich_message_in_handler and in_handler:
        sep = masker.add_literal(" | ")
        empty = masker.add_literal("")
        d = cfg.diag
        args = [sep, reindent(expr, 4),
                f"nullif({d['detail']}, {empty})",
                f"nullif({d['hint']}, {empty})",
                f"nullif({d['context']}, {empty})"]
        inner = "concat_ws\n(\n    " + ",\n    ".join(args) + "\n)"
        return _wrap_left(inner, length) if length else inner
    return _wrap_left(expr, length) if length else expr


def _error_message_expr(handler: LogHandler, expr: str, masker: Masker, length: int) -> str:
    empty = masker.add_literal("")
    unknown = masker.add_literal(handler.unknown_error_text)
    inner = ("coalesce\n(\n"
             f"    nullif({reindent(expr, 4)}, {empty}),\n"
             f"    {unknown}\n)")
    return _wrap_left(inner, length) if length else inner


def _wrap_left(expr: str, length: int) -> str:
    stripped = expr.strip()
    if not stripped or stripped.upper() == "NULL":
        return stripped or "NULL"
    if re.match(r"^left\s*\(", stripped, re.I):
        return stripped
    if "\n" in stripped:
        return f"left\n(\n    {reindent(stripped, 4)},\n    {length}\n)"
    return f"left({stripped}, {length})"


def diagnostics_block(cfg: Config) -> str:
    """The condition names are case-insensitive in PL/pgSQL; the keyword pass
    restores their upper-case spelling afterwards."""
    return DIAG_TEMPLATE.format(**cfg.diag)


def diagnostics_declarations(cfg: Config) -> List[str]:
    d = cfg.diag
    width = max(len(v) for v in d.values())
    return [f"{v.ljust(width)} text;" for v in
            (d["sqlstate"], d["message"], d["detail"], d["hint"], d["context"])]
