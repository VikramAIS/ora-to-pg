"""Collect and render everything that needs a human eye."""

from __future__ import annotations

import csv
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List

SEVERITY_ORDER = {"ERROR": 0, "WARN": 1, "INFO": 2}


@dataclass
class Note:
    severity: str
    rule: str
    snippet: str
    note: str


@dataclass
class Notes:
    object_name: str = ""
    items: List[Note] = field(default_factory=list)

    def add(self, severity: str, rule: str, snippet: str, note: str) -> None:
        snippet = re.sub(r"\s+", " ", (snippet or "")).strip()[:200]
        for existing in self.items:
            if (existing.rule, existing.snippet, existing.note) == (rule, snippet, note):
                return
        self.items.append(Note(severity.upper(), rule, snippet, note))

    def scan(self, cfg, text: str) -> None:
        for rule in cfg.review_rules:
            for m in rule.pattern.finditer(text):
                self.add(rule.severity, "pattern", m.group(0), rule.note)

    @property
    def errors(self) -> List[Note]:
        return [i for i in self.items if i.severity == "ERROR"]

    @property
    def warnings(self) -> List[Note]:
        return [i for i in self.items if i.severity == "WARN"]

    def sorted_items(self) -> List[Note]:
        return sorted(self.items, key=lambda i: (SEVERITY_ORDER.get(i.severity, 3), i.rule))

    def as_comment_block(self) -> str:
        rows = [i for i in self.sorted_items() if i.severity in ("ERROR", "WARN")]
        if not rows:
            return ""
        lines = ["-- ---------------------------------------------------------------------",
                 "-- TODO[REVIEW] - automatic conversion could not guarantee these:"]
        for i in rows:
            lines.append(f"--   [{i.severity}] {i.note}")
            if i.snippet:
                lines.append(f"--            at: {i.snippet}")
        lines.append("-- ---------------------------------------------------------------------")
        return "\n".join(lines)


def write_reports(out_dir: Path, all_notes: Dict[str, Notes], summary: List[dict]) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)

    csv_path = out_dir / "conversion_report.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["object", "severity", "rule", "snippet", "note"])
        for obj, notes in all_notes.items():
            for i in notes.sorted_items():
                w.writerow([obj, i.severity, i.rule, i.snippet, i.note])

    md: List[str] = ["# Oracle -> PostgreSQL conversion report", ""]
    total_err = sum(len(n.errors) for n in all_notes.values())
    total_warn = sum(len(n.warnings) for n in all_notes.values())
    md += [
        f"* objects processed: **{len(summary)}**",
        f"* generated functions: **{sum(s['functions'] for s in summary)}**",
        f"* blocking items (ERROR): **{total_err}**",
        f"* review items (WARN): **{total_warn}**",
        "",
        "## Objects",
        "",
        "| Object | Functions | Errors | Warnings | Output |",
        "|---|---:|---:|---:|---|",
    ]
    for s in summary:
        n = all_notes.get(s["object"], Notes())
        md.append(f"| `{s['object']}` | {s['functions']} | {len(n.errors)} | "
                  f"{len(n.warnings)} | `{s['output']}` |")

    md += ["", "## Details", ""]
    for obj, notes in all_notes.items():
        rows = notes.sorted_items()
        if not rows:
            continue
        md += [f"### `{obj}`", "", "| Severity | Rule | Snippet | Note |", "|---|---|---|---|"]
        for i in rows:
            snippet = i.snippet.replace("|", "\\|")
            md.append(f"| {i.severity} | {i.rule} | `{snippet}` | {i.note.replace('|', chr(92) + '|')} |")
        md.append("")

    (out_dir / "conversion_report.md").write_text("\n".join(md), encoding="utf-8")
