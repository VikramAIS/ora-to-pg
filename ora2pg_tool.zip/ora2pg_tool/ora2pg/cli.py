"""Command line entry point.

  # 1. offline (DDL already exported to .sql files)
  python -m ora2pg convert --proc-list config/proc_list.txt --source-dir ddl_in --out out

  # 2. straight from Oracle
  set ORA_PASSWORD=...
  python -m ora2pg convert --proc-list config/proc_list.txt \
      --dsn host:1521/SERVICE --user CPDQ999 --out out

  # 3. just pull the DDL
  python -m ora2pg extract --proc-list config/proc_list.txt --dsn ... --out out

  # 4. build the column catalog CSV from a pasted psql/information_schema dump
  python -m ora2pg import-columns --input columns_dump.txt --out config/pg_columns.csv
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional

from .config import Config
from .converter import Converter
from .extractor import OracleExtractor, SourceObject, fetch_from_dir, parse_proc_list
from .report import Notes, write_reports

DEFAULT_CONFIG = Path(__file__).resolve().parent.parent / "config" / "mappings.yaml"


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="ora2pg", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="command", required=True)

    def common(sp):
        sp.add_argument("--proc-list", type=Path, required=True,
                        help="File with one SCHEMA.OBJECT[.SUBPROGRAM] per line.")
        sp.add_argument("--out", type=Path, default=Path("out"))
        sp.add_argument("--dsn", default=os.environ.get("ORA_DSN"))
        sp.add_argument("--user", default=os.environ.get("ORA_USER"))
        sp.add_argument("--password", default=os.environ.get("ORA_PASSWORD"))
        sp.add_argument("--thick-lib", default=os.environ.get("ORA_CLIENT_LIB"),
                        help="Instant Client dir, if thick mode is required.")
        sp.add_argument("--source-dir", type=Path,
                        help="Read DDL from .sql files instead of connecting to Oracle.")

    c = sub.add_parser("convert", help="Extract (or read) and convert to PostgreSQL.")
    common(c)
    c.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    c.add_argument("--columns-csv", type=Path)
    c.add_argument("--single-file", action="store_true",
                   help="Also write one combined deploy script.")
    c.add_argument("--continue-on-error", action="store_true", default=True)

    e = sub.add_parser("extract", help="Only pull the Oracle DDL.")
    common(e)

    i = sub.add_parser("import-columns", help="Turn a pasted column dump into a CSV catalog.")
    i.add_argument("--input", type=Path, required=True)
    i.add_argument("--out", type=Path, default=Path("config/pg_columns.csv"))
    return p


# --------------------------------------------------------------------- source
def _load_sources(args) -> List[SourceObject]:
    entries = parse_proc_list(args.proc_list)
    sources: List[SourceObject] = []
    extractor: Optional[OracleExtractor] = None
    try:
        if not args.source_dir:
            if not (args.dsn and args.user and args.password):
                raise SystemExit("Provide --source-dir, or --dsn/--user/--password "
                                 "(or ORA_DSN/ORA_USER/ORA_PASSWORD).")
            extractor = OracleExtractor(args.dsn, args.user, args.password, args.thick_lib)

        seen = set()
        for owner, name, sub in entries:
            try:
                if extractor:
                    key = (owner, name)
                    if key in seen and sub is None:
                        continue
                    seen.add(key)
                    obj = extractor.fetch(owner, name, sub)
                else:
                    obj = fetch_from_dir(args.source_dir, owner, name, sub)
                sources.append(obj)
            except Exception as exc:  # noqa: BLE001 - one bad object must not stop 290 others
                print(f"[SKIP] {owner}.{name}: {exc}", file=sys.stderr)
    finally:
        if extractor:
            extractor.close()
    return sources


def _safe_name(obj: SourceObject) -> str:
    return re.sub(r"[^\w.]+", "_", obj.key).lower()


# ------------------------------------------------------------------- commands
def cmd_extract(args) -> int:
    out_dir = Path(args.out) / "oracle_ddl"
    out_dir.mkdir(parents=True, exist_ok=True)
    sources = _load_sources(args)
    for obj in sources:
        (out_dir / f"{obj.schema}.{obj.name}.sql").write_text(obj.ddl, encoding="utf-8")
    print(f"Extracted {len(sources)} object(s) into {out_dir}")
    return 0


def cmd_convert(args) -> int:
    cfg = Config.load(args.config, args.columns_csv)
    # Names from the work list let the converter recognise PKG.PROC(...) calls
    # that are written without a schema prefix.
    known = {name for _, name, _ in parse_proc_list(args.proc_list)}
    converter = Converter(cfg, known_packages=known)

    out_root = Path(args.out)
    ddl_dir = out_root / "oracle_ddl"
    pg_dir = out_root / "postgres"
    ddl_dir.mkdir(parents=True, exist_ok=True)
    pg_dir.mkdir(parents=True, exist_ok=True)

    sources = _load_sources(args)
    if not sources:
        print("Nothing to convert.", file=sys.stderr)
        return 1

    all_notes: Dict[str, Notes] = {}
    summary: List[dict] = []
    combined: List[str] = []

    for obj in sources:
        (ddl_dir / f"{obj.schema}.{obj.name}.sql").write_text(obj.ddl, encoding="utf-8")
        try:
            result = converter.convert(obj)
        except Exception as exc:  # noqa: BLE001
            notes = Notes(object_name=obj.key)
            notes.add("ERROR", "crash", type(exc).__name__, f"Converter failed: {exc}")
            all_notes[obj.key] = notes
            summary.append({"object": obj.key, "functions": 0, "output": "-"})
            print(f"[FAIL] {obj.key}: {exc}", file=sys.stderr)
            if not args.continue_on_error:
                raise
            continue

        target = pg_dir / f"{_safe_name(obj)}.sql"
        target.write_text(result.sql, encoding="utf-8")
        combined.append(result.sql)
        all_notes[obj.key] = result.notes
        summary.append({"object": obj.key, "functions": len(result.units),
                        "output": str(target.relative_to(out_root))})
        flag = "ERR " if result.notes.errors else ("warn" if result.notes.warnings else "ok  ")
        print(f"[{flag}] {obj.key}: {len(result.units)} function(s) -> {target.name}")

    if args.single_file:
        (out_root / "deploy_all.sql").write_text("\n\n".join(combined), encoding="utf-8")

    write_reports(out_root, all_notes, summary)
    errors = sum(len(n.errors) for n in all_notes.values())
    print(f"\nDone. {len(summary)} object(s), "
          f"{sum(s['functions'] for s in summary)} function(s), {errors} blocking item(s).")
    print(f"Report: {out_root / 'conversion_report.md'}")
    return 0


_DUMP_TOKEN_RE = re.compile(r'"([^"]*)"|(\S+)')


def cmd_import_columns(args) -> int:
    """Parse a loose column dump (like the one in your screenshot) into CSV."""
    import csv

    rows = []
    for line in Path(args.input).read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("--"):
            continue
        toks = [a or b for a, b in _DUMP_TOKEN_RE.findall(line)]
        if len(toks) < 4:
            continue
        schema, table, column = toks[0], toks[1], toks[2]
        rest = toks[3:]
        length = next((t for t in rest if t.isdigit()), "")
        nullable = next((t for t in rest if t.upper() in ("YES", "NO")), "")
        type_toks = [t for t in rest if t != length and t.upper() not in ("YES", "NO")]
        udt = type_toks[-1] if type_toks else "text"
        rows.append({"schema": schema.lower(), "table": table.lower(),
                     "column": column.lower(),
                     "data_type": " ".join(type_toks).lower() or "text",
                     "udt_name": udt.lower(), "length": length, "nullable": nullable})

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["schema", "table", "column", "data_type",
                                           "udt_name", "length", "nullable"])
        w.writeheader()
        w.writerows(rows)
    print(f"Wrote {len(rows)} column(s) to {out}")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "convert":
        return cmd_convert(args)
    if args.command == "extract":
        return cmd_extract(args)
    return cmd_import_columns(args)


if __name__ == "__main__":
    raise SystemExit(main())
