"""Mask string literals, comments and quoted identifiers so that regex based
transforms can never corrupt them.

Every masked chunk becomes ``\\x01<index>\\x02`` which contains no word
characters, so ``\\b`` anchored patterns behave exactly as if the chunk were a
single opaque token.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List

OPEN = "\x01"
CLOSE = "\x02"

_PLACEHOLDER_RE = re.compile(r"\x01(\d+)\x02")

_Q_DELIM_CLOSE = {"[": "]", "(": ")", "{": "}", "<": ">"}


@dataclass
class Chunk:
    kind: str  # 'string' | 'comment' | 'ident'
    text: str  # the original text, including its delimiters


@dataclass
class Masker:
    chunks: List[Chunk] = field(default_factory=list)

    # ------------------------------------------------------------------ mask
    def mask(self, sql: str) -> str:
        out: List[str] = []
        i, n = 0, len(sql)
        while i < n:
            ch = sql[i]
            nxt = sql[i + 1] if i + 1 < n else ""

            if ch == "-" and nxt == "-":
                j = sql.find("\n", i)
                j = n if j == -1 else j
                out.append(self._store("comment", sql[i:j]))
                i = j
            elif ch == "/" and nxt == "*":
                j = sql.find("*/", i + 2)
                j = n if j == -1 else j + 2
                out.append(self._store("comment", sql[i:j]))
                i = j
            elif ch in "qQ" and nxt == "'" and i + 2 < n:
                j = self._scan_q_literal(sql, i)
                out.append(self._store("string", sql[i:j]))
                i = j
            elif ch == "'":
                j = self._scan_string(sql, i)
                out.append(self._store("string", sql[i:j]))
                i = j
            elif ch == '"':
                j = sql.find('"', i + 1)
                j = n if j == -1 else j + 1
                out.append(self._store("ident", sql[i:j]))
                i = j
            else:
                out.append(ch)
                i += 1
        return "".join(out)

    @staticmethod
    def _scan_string(sql: str, start: int) -> int:
        i, n = start + 1, len(sql)
        while i < n:
            if sql[i] == "'":
                if i + 1 < n and sql[i + 1] == "'":
                    i += 2
                    continue
                return i + 1
            i += 1
        return n

    @staticmethod
    def _scan_q_literal(sql: str, start: int) -> int:
        opener = sql[start + 2]
        closer = _Q_DELIM_CLOSE.get(opener, opener)
        j = sql.find(closer + "'", start + 3)
        return len(sql) if j == -1 else j + 2

    # --------------------------------------------------------------- helpers
    def _store(self, kind: str, text: str) -> str:
        self.chunks.append(Chunk(kind, text))
        return f"{OPEN}{len(self.chunks) - 1}{CLOSE}"

    def add_literal(self, value: str) -> str:
        """Register a *new* SQL string literal and return its placeholder.

        Use this whenever a transform emits a literal, otherwise later passes
        (identifier lower-casing, keyword upper-casing) would rewrite its text.
        """
        return self._store("string", "'" + value.replace("'", "''") + "'")

    def add_raw(self, text: str) -> str:
        """Register text that must survive verbatim (already-formed SQL)."""
        return self._store("raw", text)

    def kind_at(self, token: str) -> str:
        m = _PLACEHOLDER_RE.fullmatch(token.strip())
        return self.chunks[int(m.group(1))].kind if m else ""

    def text_at(self, token: str) -> str:
        m = _PLACEHOLDER_RE.search(token)
        return self.chunks[int(m.group(1))].text if m else ""

    def is_placeholder(self, token: str) -> bool:
        return bool(_PLACEHOLDER_RE.fullmatch(token.strip()))

    # ---------------------------------------------------------------- unmask
    def unmask(self, sql: str) -> str:
        def repl(m: re.Match) -> str:
            return self.chunks[int(m.group(1))].text

        # Loop because add_raw() content may itself contain placeholders.
        for _ in range(10):
            new = _PLACEHOLDER_RE.sub(repl, sql)
            if new == sql:
                break
            sql = new
        return sql

    def strip_masked(self, sql: str) -> str:
        """Return `sql` with every masked chunk replaced by a blank of the same
        length. Useful for position-preserving scans."""

        def repl(m: re.Match) -> str:
            return " " * len(m.group(0))

        return _PLACEHOLDER_RE.sub(repl, sql)
