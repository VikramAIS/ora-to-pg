"""Split an Oracle package body (or standalone program) into subprograms and
parse each header into parameters + return type.

Works on *masked* text (see masking.Masker) so literals and comments can never
be mistaken for keywords.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from .sqlutil import Token, split_top_level, tokenize

_DEF_TERMINATORS = {"IS", "AS"}
_BLOCK_CLOSERS = {"IF", "LOOP", "CASE"}
_BLOCK_OPENERS = {"BEGIN", "IF", "LOOP", "CASE"}


@dataclass
class Param:
    name: str
    mode: str          # IN | OUT | INOUT
    oracle_type: str
    default: Optional[str] = None
    pg_type: str = ""


@dataclass
class Unit:
    kind: str          # PROCEDURE | FUNCTION
    name: str
    start: int         # offset of the PROCEDURE/FUNCTION keyword
    is_pos: int        # offset just after IS/AS
    end: int = -1      # offset just after the closing ';'
    params_text: str = ""
    return_type: str = ""
    depth: int = 0
    nested: List["Unit"] = field(default_factory=list)

    def text(self, masked: str) -> str:
        return masked[self.start:self.end]

    def body(self, masked: str) -> str:
        return masked[self.is_pos:self.end]


def package_name(masked: str) -> Optional[str]:
    m = re.search(
        r"\bCREATE\s+(?:OR\s+REPLACE\s+)?(?:EDITIONABLE\s+|NONEDITIONABLE\s+)?"
        r"PACKAGE\s+BODY\s+([A-Za-z_][\w$#]*)\s*(?:\.\s*([A-Za-z_][\w$#]*))?",
        masked, re.I)
    if not m:
        m = re.search(r"\bPACKAGE\s+BODY\s+([A-Za-z_][\w$#]*)\s*(?:\.\s*([A-Za-z_][\w$#]*))?",
                      masked, re.I)
    if not m:
        return None
    return (m.group(2) or m.group(1)).upper()


def split_units(masked: str) -> List[Unit]:
    """Return the top-level subprograms; nested ones hang off ``Unit.nested``."""
    tokens = tokenize(masked)
    units: List[Unit] = []
    stack: List[Unit] = []
    depth = 0
    i = 0
    n = len(tokens)

    while i < n:
        tok = tokens[i]
        up = tok.up

        if up in ("PROCEDURE", "FUNCTION"):
            parsed = _parse_header(tokens, i, masked)
            if parsed is not None:
                unit, next_i = parsed
                unit.depth = depth
                stack.append(unit)
                i = next_i
                continue

        if up == "END":
            nxt = tokens[i + 1].up if i + 1 < n else ""
            depth -= 1
            if nxt in _BLOCK_CLOSERS:
                i += 2
                continue
            if stack and depth == stack[-1].depth:
                unit = stack.pop()
                semi = _semicolon_after(tokens, i)
                unit.end = tokens[semi].end
                (units if not stack else stack[-1].nested).append(unit)
                i = semi + 1
                continue
            if depth < 0:  # package END / stray END
                depth = 0
        elif up in _BLOCK_OPENERS:
            depth += 1

        i += 1

    # A truncated package (missing final END) still yields usable units.
    while stack:
        unit = stack.pop()
        unit.end = len(masked)
        (units if not stack else stack[-1].nested).append(unit)
    units.sort(key=lambda u: u.start)
    return units


def _semicolon_after(tokens: List[Token], idx: int) -> int:
    for j in range(idx, len(tokens)):
        if tokens[j].text == ";":
            return j
    return len(tokens) - 1


def _parse_header(tokens: List[Token], idx: int, masked: str) -> Optional[Tuple[Unit, int]]:
    """Parse ``PROCEDURE|FUNCTION name [(params)] [RETURN t] IS|AS``.

    Returns None for a forward declaration (spec only, ends with ``;``).
    """
    kind = tokens[idx].up
    j = idx + 1
    if j >= len(tokens) or not re.match(r"[A-Za-z_]", tokens[j].text):
        return None
    name = tokens[j].text
    j += 1
    # Qualified standalone object: SCHEMA.NAME
    if j + 1 < len(tokens) and tokens[j].text == "." and re.match(r"[A-Za-z_]", tokens[j + 1].text):
        name = tokens[j + 1].text
        j += 2

    params_text = ""
    if j < len(tokens) and tokens[j].text == "(":
        close = _matching_paren_token(tokens, j)
        if close == -1:
            return None
        params_text = masked[tokens[j].end:tokens[close].start]
        j = close + 1

    return_type = ""
    depth = 0
    while j < len(tokens):
        t = tokens[j]
        if t.text == "(":
            depth += 1
        elif t.text == ")":
            depth -= 1
        elif depth == 0:
            if t.text == ";":
                return None  # forward declaration
            if t.up == "RETURN":
                k = j + 1
                start = tokens[k].start if k < len(tokens) else t.end
                while k < len(tokens) and tokens[k].up not in _DEF_TERMINATORS and tokens[k].text != ";":
                    k += 1
                return_type = masked[start:tokens[k - 1].end].strip() if k > j + 1 else ""
                j = k
                continue
            if t.up in _DEF_TERMINATORS:
                unit = Unit(kind=kind, name=name.upper(), start=tokens[idx].start,
                            is_pos=t.end, params_text=params_text, return_type=return_type)
                return unit, j + 1
        j += 1
    return None


def _matching_paren_token(tokens: List[Token], open_idx: int) -> int:
    depth = 0
    for i in range(open_idx, len(tokens)):
        if tokens[i].text == "(":
            depth += 1
        elif tokens[i].text == ")":
            depth -= 1
            if depth == 0:
                return i
    return -1


_PARAM_RE = re.compile(
    r"^\s*(?P<name>[A-Za-z_][\w$#]*)\s+"
    r"(?P<mode>(?:IN\s+OUT|INOUT|IN|OUT)\s+)?"
    r"(?:NOCOPY\s+)?"
    r"(?P<type>.+?)"
    r"(?:\s*(?::=|\bDEFAULT\b)\s*(?P<default>.+))?$",
    re.I | re.S,
)


def parse_params(params_text: str) -> List[Param]:
    params: List[Param] = []
    if not params_text.strip():
        return params
    for chunk in split_top_level(params_text, ","):
        if not chunk.strip():
            continue
        m = _PARAM_RE.match(chunk)
        if not m:
            continue
        mode = (m.group("mode") or "IN").strip().upper()
        mode = "INOUT" if mode in ("IN OUT", "INOUT") else mode
        params.append(Param(
            name=m.group("name"),
            mode=mode,
            oracle_type=re.sub(r"\s+", " ", m.group("type")).strip(),
            default=(m.group("default") or "").strip() or None,
        ))
    return params


def split_body(body_masked: str) -> Tuple[str, str, str]:
    """Split a subprogram body into (declare, executable, exception) sections.

    `body_masked` is everything after ``IS``/``AS`` up to and including the final
    ``END ...;``.
    """
    tokens = tokenize(body_masked)
    depth = 0
    begin_idx = end_idx = exc_idx = -1
    i, n = 0, len(tokens)

    while i < n:
        up = tokens[i].up
        if up in ("PROCEDURE", "FUNCTION") and depth == 0 and begin_idx == -1:
            # A nested subprogram in the DECLARE part - skip over its whole body.
            j = _skip_nested(tokens, i)
            if j != i:
                i = j
                continue
        if up == "END":
            nxt = tokens[i + 1].up if i + 1 < n else ""
            depth -= 1
            if nxt in _BLOCK_CLOSERS:
                i += 2
                continue
            if depth == 0 and begin_idx != -1:
                end_idx = i
                break
        elif up in _BLOCK_OPENERS:
            if up == "BEGIN" and depth == 0 and begin_idx == -1:
                begin_idx = i
            depth += 1
        elif up == "EXCEPTION" and depth == 1 and exc_idx == -1:
            nxt = tokens[i + 1].up if i + 1 < n else ""
            if nxt == "WHEN":
                exc_idx = i
        i += 1

    if begin_idx == -1:
        return body_masked, "", ""

    declare = body_masked[:tokens[begin_idx].start]
    body_end = tokens[end_idx].start if end_idx != -1 else len(body_masked)
    if exc_idx != -1:
        executable = body_masked[tokens[begin_idx].end:tokens[exc_idx].start]
        exception = body_masked[tokens[exc_idx].end:body_end]
    else:
        executable = body_masked[tokens[begin_idx].end:body_end]
        exception = ""
    return declare, executable, exception


def _skip_nested(tokens: List[Token], idx: int) -> int:
    """Advance past a nested subprogram definition; returns `idx` if it is only
    a forward declaration."""
    depth = 0
    i = idx + 1
    seen_is = False
    n = len(tokens)
    while i < n:
        up = tokens[i].up
        if not seen_is:
            if tokens[i].text == "(":
                depth += 1
            elif tokens[i].text == ")":
                depth -= 1
            elif depth == 0 and tokens[i].text == ";":
                return i + 1
            elif depth == 0 and up in _DEF_TERMINATORS:
                seen_is = True
                depth = 0
            i += 1
            continue
        if up == "END":
            nxt = tokens[i + 1].up if i + 1 < n else ""
            depth -= 1
            if nxt in _BLOCK_CLOSERS:
                i += 2
                continue
            if depth == 0:
                while i < n and tokens[i].text != ";":
                    i += 1
                return i + 1
        elif up in _BLOCK_OPENERS:
            depth += 1
        i += 1
    return n
