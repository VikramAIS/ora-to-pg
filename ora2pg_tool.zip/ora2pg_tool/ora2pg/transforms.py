"""Data-type mapping and Oracle -> PostgreSQL expression / statement rewrites."""

from __future__ import annotations

import re
from typing import List, Optional

from .config import Config
from .masking import Masker
from .sqlutil import find_matching_paren, split_top_level

_NUMBER_RE = re.compile(r"^NUMBER\s*(?:\(\s*(\*|\d+)\s*(?:,\s*(-?\d+)\s*)?\))?$", re.I)
_VARCHAR_RE = re.compile(r"^N?(?:VARCHAR2?|CHAR)\s*\(\s*(\d+)\s*(?:BYTE|CHAR)?\s*\)$", re.I)
_ANCHORED_RE = re.compile(r"^[\w.$#]+%(?:TYPE|ROWTYPE)$", re.I)


# --------------------------------------------------------------------- types
def map_datatype(cfg: Config, oracle_type: str, var_name: str = "") -> str:
    t = re.sub(r"\s+", " ", (oracle_type or "").strip()).rstrip(";")
    lname = (var_name or "").lower()

    if cfg.var_name_wins and lname in cfg.var_by_name:
        return cfg.var_by_name[lname]

    if _ANCHORED_RE.match(t):  # tbl.col%TYPE works unchanged in PL/pgSQL
        return t.lower()

    mapped = _map_core(cfg, t)

    if mapped is None and lname in cfg.var_by_name:
        return cfg.var_by_name[lname]
    if mapped is None or cfg.var_suffix_wins:
        for suffix, pgtype in cfg.var_by_suffix.items():
            if lname.endswith(suffix):
                return pgtype
    return mapped or (t.lower() if t else "text")


def _map_core(cfg: Config, t: str) -> Optional[str]:
    m = _NUMBER_RE.match(t)
    if m:
        prec = m.group(1)
        scale = m.group(2)
        if prec in (None, "*"):
            return cfg.number_bare
        if scale not in (None, "0"):
            return f"numeric({prec},{scale})"
        p = int(prec)
        if p <= cfg.num_int_prec:
            return "integer"
        if p <= cfg.num_bigint_prec:
            return "bigint"
        return f"numeric({prec})"

    m = _VARCHAR_RE.match(t)
    if m:
        return f"varchar({m.group(1)})" if cfg.keep_varchar_length else "text"

    for pattern, replacement in cfg.type_rules:
        if pattern.match(t):
            try:
                return pattern.sub(replacement, t, count=1).lower()
            except re.error:
                return replacement.lower()
    return None


# ------------------------------------------------------------- declarations
_DECL_RE = re.compile(
    r"^(?P<indent>[ \t]*)(?P<name>[A-Za-z_][\w$#]*)\s+"
    r"(?P<const>CONSTANT\s+)?"
    r"(?P<type>[^:;]+?)"
    r"(?P<notnull>\s+NOT\s+NULL)?"
    r"(?:\s*(?::=|\bDEFAULT\b)\s*(?P<default>.+?))?\s*;\s*$",
    re.I | re.S,
)
_CURSOR_RE = re.compile(
    r"\bCURSOR\s+(?P<name>[A-Za-z_][\w$#]*)\s*(?P<params>\([^;]*?\))?\s+IS\s+",
    re.I,
)
_USER_EXC_RE = re.compile(r"^\s*([A-Za-z_][\w$#]*)\s+EXCEPTION\s*;\s*$", re.I | re.M)


def transform_declarations(cfg: Config, masked: str, notes) -> str:
    """Rewrite the DECLARE section: types, cursors, user exceptions."""
    masked = _CURSOR_RE.sub(
        lambda m: f"{m.group('name')} CURSOR{m.group('params') or ''} FOR ", masked)

    for m in _USER_EXC_RE.finditer(masked):
        notes.add("WARN", "user-exception", m.group(0).strip(),
                  f"User-defined exception {m.group(1)} - PostgreSQL has no exception "
                  f"declarations; raise with a custom SQLSTATE instead.")
    masked = _USER_EXC_RE.sub(
        lambda m: f"-- TODO[REVIEW] user-defined exception: {m.group(0).strip()}", masked)

    out: List[str] = []
    for stmt in _iter_declarations(masked):
        if re.search(r"\bCURSOR\b", stmt, re.I):
            out.append(stmt)  # keep the cursor query formatting intact
            continue
        m = _DECL_RE.match(stmt)
        if not m:
            out.append(stmt)
            continue
        name = m.group("name")
        if name.upper() in ("CURSOR", "PRAGMA", "TYPE", "SUBTYPE"):
            out.append(stmt)
            continue
        pg_type = map_datatype(cfg, m.group("type"), name)
        pieces = [f"{m.group('indent')}{rename_identifier(cfg, name)}"]
        if m.group("const"):
            pieces.append("CONSTANT")
        pieces.append(pg_type)
        if m.group("notnull"):
            pieces.append("NOT NULL")
        if m.group("default"):
            pieces.append(f":= {m.group('default').strip()}")
        out.append(" ".join(pieces) + ";")
    return "\n".join(out)


def _iter_declarations(masked: str) -> List[str]:
    """Split the DECLARE section into statements on top-level semicolons."""
    stmts, depth, buf = [], 0, []
    for ch in masked:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        buf.append(ch)
        if ch == ";" and depth == 0:
            stmts.append("".join(buf).strip())
            buf = []
    tail = "".join(buf).strip()
    if tail:
        stmts.append(tail)
    return [s for s in stmts if s]


def rename_identifier(cfg: Config, name: str) -> str:
    return cfg.var_renames.get(name.lower(), name.lower())


# ----------------------------------------------------------------- builtins
def transform_builtins(cfg: Config, masked: str, masker: Masker, notes) -> str:
    masked = _rewrite_decode(masked)
    masked = _rewrite_calls(cfg, masked, masker, notes)
    masked = _rewrite_tokens(cfg, masked)
    masked = _rewrite_misc(cfg, masked, masker, notes)
    return masked


def _rewrite_calls(cfg: Config, masked: str, masker: Masker, notes) -> str:
    def repl(m: re.Match) -> str:
        fn = m.group(1).upper()
        target = cfg.builtin_calls.get(fn)
        if target is None:
            return m.group(0)
        if target.startswith("__"):
            return m.group(0)  # handled by _rewrite_misc
        return f"{target}("

    masked = re.sub(r"\b([A-Za-z_][\w$#]*)\s*\(", repl, masked)

    for fn in ("ADD_MONTHS", "MONTHS_BETWEEN", "LAST_DAY"):
        masked = _rewrite_date_fn(masked, fn, notes)
    return masked


def _rewrite_date_fn(masked: str, fn: str, notes) -> str:
    pattern = re.compile(rf"\b{fn}\s*\(", re.I)
    while True:
        m = pattern.search(masked)
        if not m:
            return masked
        close = find_matching_paren(masked, m.end() - 1)
        if close == -1:
            return masked
        args = split_top_level(masked[m.end():close])
        if fn == "ADD_MONTHS" and len(args) == 2:
            new = f"(({args[0]})::timestamp + (({args[1]}) || ' month')::interval)"
        elif fn == "MONTHS_BETWEEN" and len(args) == 2:
            new = (f"(extract(YEAR FROM age(({args[0]})::timestamp, ({args[1]})::timestamp)) * 12"
                   f" + extract(MONTH FROM age(({args[0]})::timestamp, ({args[1]})::timestamp)))")
        elif fn == "LAST_DAY" and len(args) == 1:
            new = (f"((date_trunc('month', ({args[0]})::timestamp) "
                   f"+ interval '1 month - 1 day')::date)")
        else:
            notes.add("WARN", fn.lower(), masked[m.start():close + 1],
                      f"{fn} could not be rewritten automatically.")
            return masked[:m.start()] + masked[m.start():close + 1].replace(fn, fn + "_TODO", 1) \
                + masked[close + 1:]
        masked = masked[:m.start()] + new + masked[close + 1:]


def _rewrite_tokens(cfg: Config, masked: str) -> str:
    for token, repl in cfg.builtin_tokens.items():
        masked = re.sub(rf"\b{re.escape(token)}\b", repl, masked, flags=re.I)
    return masked


def _rewrite_decode(masked: str) -> str:
    """DECODE(e, s1, r1, ..., def) -> CASE e WHEN s1 THEN r1 ... ELSE def END."""
    pattern = re.compile(r"\bDECODE\s*\(", re.I)
    while True:
        m = pattern.search(masked)
        if not m:
            return masked
        close = find_matching_paren(masked, m.end() - 1)
        if close == -1:
            return masked
        args = split_top_level(masked[m.end():close])
        if len(args) < 3:
            return masked
        expr, rest = args[0], args[1:]
        parts = [f"CASE WHEN {expr} IS NOT DISTINCT FROM {rest[i]} THEN {rest[i + 1]}"
                 if i == 0 else f"WHEN {expr} IS NOT DISTINCT FROM {rest[i]} THEN {rest[i + 1]}"
                 for i in range(0, len(rest) - 1, 2)]
        tail = rest[-1] if len(rest) % 2 else None
        new = " ".join(parts) + (f" ELSE {tail}" if tail is not None else "") + " END"
        masked = masked[:m.start()] + "(" + new + ")" + masked[close + 1:]


def _rewrite_misc(cfg: Config, masked: str, masker: Masker, notes) -> str:
    # SUBSTR(x, 1, n) is Oracle's idiom for "truncate to n" -> left(x, n)
    pattern = re.compile(r"\bsubstr\s*\(", re.I)
    pos = 0
    while True:
        m = pattern.search(masked, pos)
        if not m:
            break
        close = find_matching_paren(masked, m.end() - 1)
        if close == -1:
            break
        args = split_top_level(masked[m.end():close])
        if len(args) == 3 and args[1].strip() == "1":
            new = f"left({args[0]}, {args[2]})"
            masked = masked[:m.start()] + new + masked[close + 1:]
            pos = m.start() + len(new)
        else:
            pos = close + 1

    # sequence.NEXTVAL / .CURRVAL
    def seq(m: re.Match) -> str:
        fn = "nextval" if m.group(2).upper() == "NEXTVAL" else "currval"
        return f"{fn}({masker.add_literal(m.group(1).lower())})"

    masked = re.sub(r"\b([\w$#]+(?:\.[\w$#]+)?)\s*\.\s*(NEXTVAL|CURRVAL)\b", seq, masked, flags=re.I)

    # FROM DUAL
    masked = re.sub(r"\bFROM\s+(?:SYS\.)?DUAL\b", "", masked, flags=re.I)

    # DBMS_OUTPUT.PUT_LINE(x) -> RAISE NOTICE '%', x;
    pattern = re.compile(r"\bDBMS_OUTPUT\s*\.\s*PUT_LINE\s*\(", re.I)
    while True:
        m = pattern.search(masked)
        if not m:
            break
        close = find_matching_paren(masked, m.end() - 1)
        if close == -1:
            break
        arg = masked[m.end():close].strip()
        masked = masked[:m.start()] + f"RAISE NOTICE {masker.add_literal('%')}, {arg}" \
            + masked[close + 1:]

    # RAISE_APPLICATION_ERROR(-20001, msg)
    pattern = re.compile(r"\bRAISE_APPLICATION_ERROR\s*\(", re.I)
    while True:
        m = pattern.search(masked)
        if not m:
            break
        close = find_matching_paren(masked, m.end() - 1)
        if close == -1:
            break
        args = split_top_level(masked[m.end():close])
        msg = args[1] if len(args) > 1 else masker.add_literal("Application error")
        code = args[0].strip().lstrip("-")
        errcode = masker.add_literal("P0001")
        masked = (masked[:m.start()]
                  + f"RAISE EXCEPTION {masker.add_literal('%')}, {msg} USING ERRCODE = {errcode}"
                  + masked[close + 1:])
        notes.add("WARN", "raise-application-error", f"ORA-{code}",
                  "RAISE EXCEPTION emitted with SQLSTATE P0001 - map to your own SQLSTATE "
                  "if callers depend on the ORA number.")

    # EXECUTE IMMEDIATE -> EXECUTE
    masked = re.sub(r"\bEXECUTE\s+IMMEDIATE\b", "EXECUTE", masked, flags=re.I)

    # TO_NUMBER(x) with no format mask is invalid in PostgreSQL.
    pattern = re.compile(r"\bto_number\s*\(", re.I)
    pos = 0
    while True:
        m = pattern.search(masked, pos)
        if not m:
            break
        close = find_matching_paren(masked, m.end() - 1)
        if close == -1:
            break
        args = split_top_level(masked[m.end():close])
        if len(args) == 1:
            new = f"({args[0]})::numeric"
            masked = masked[:m.start()] + new + masked[close + 1:]
            pos = m.start() + len(new)
        else:
            pos = close + 1

    # Transaction control is illegal inside a PostgreSQL function.
    def kill_txn(m: re.Match) -> str:
        notes.add("ERROR", "transaction-control", m.group(1).upper(),
                  f"{m.group(1).upper()} commented out - a PostgreSQL function runs inside "
                  "the caller's transaction. Move the transaction control to the caller, or "
                  "convert this object to a PROCEDURE.")
        return f"-- TODO[REVIEW] {m.group(0)}"

    masked = re.sub(r"\b(COMMIT|ROLLBACK)\b\s*;", kill_txn, masked, flags=re.I)

    # cursor%NOTFOUND / %FOUND  -> NOT FOUND / FOUND
    masked = re.sub(r"\b[\w$#]+\s*%\s*NOTFOUND\b", "NOT FOUND", masked, flags=re.I)
    masked = re.sub(r"\b[\w$#]+\s*%\s*FOUND\b", "FOUND", masked, flags=re.I)

    # SQL%ROWCOUNT is handled manually - flagged by the review rules.
    masked = re.sub(r"\bMINUS\b", "EXCEPT", masked, flags=re.I)
    masked = re.sub(r"\bELSIF\b", "ELSIF", masked, flags=re.I)
    masked = re.sub(r"\bGOTO\b", "-- TODO[REVIEW] GOTO", masked, flags=re.I)
    masked = re.sub(r"\bPRAGMA\s+[^\n;]+;", lambda m: f"-- TODO[REVIEW] {m.group(0)}",
                    masked, flags=re.I)

    # Oracle string concat with NULL keeps the other side - PostgreSQL yields NULL.
    return masked


# --------------------------------------------------------- packaged programs
_THREE_PART_CALL = re.compile(
    r"\b([A-Za-z_][\w$#]*)\s*\.\s*([A-Za-z_][\w$#]*)\s*\.\s*([A-Za-z_][\w$#]*)\s*(?=\()")
_THREE_PART_REF = re.compile(
    r"\b([A-Za-z_][\w$#]*)\s*\.\s*([A-Za-z_][\w$#]*)\s*\.\s*([A-Za-z_][\w$#]*)\b(?!\s*[.(])")
_TWO_PART_CALL = re.compile(
    r"(?<![\w$#.])([A-Za-z_][\w$#]*)\s*\.\s*([A-Za-z_][\w$#]*)\s*(?=\()")
_ANY_CALL = re.compile(
    r"(?<![\w$#.])([A-Za-z_][\w$#]*(?:\s*\.\s*[A-Za-z_][\w$#]*)*)\s*(?=\()")
_INT_MATH = re.compile(r"(?<![\w$#.])(\d+)\s*([+-])\s*(\d+)(?![\w$#.])")


def lookup_function(cfg: Config, dotted: str) -> Optional[str]:
    """Most specific match wins: SCHEMA.PACKAGE.PROC, then PACKAGE.PROC, then PROC."""
    parts = re.sub(r"\s+", "", dotted).upper().split(".")
    for n in range(len(parts), 0, -1):
        target = cfg.function_map.get(".".join(parts[-n:]))
        if target:
            return target
    return None


def _fold_int_math(text: str) -> str:
    """Substituting a package constant leaves things like ``1 + 1``; fold them."""
    while True:
        new = _INT_MATH.sub(
            lambda m: str(int(m.group(1)) + int(m.group(3)) if m.group(2) == "+"
                          else int(m.group(1)) - int(m.group(3))),
            text)
        if new == text:
            return text
        text = new


def rewrite_package_calls(cfg: Config, masked: str, known_packages, default_schema: str,
                          notes) -> str:
    """``SCHEMA.PKG.PROC(`` -> ``schema.pkg_proc(`` and ``PKG.PROC(`` -> the same.

    Run this *after* the logging handlers, otherwise the log calls get renamed
    generically instead of being mapped to your PostgreSQL logging functions.
    """
    pkgs = {p.lower() for p in known_packages}

    # Package constants have no PostgreSQL equivalent - substitute the value the
    # user configured before anything else touches the reference.
    def constant(m: re.Match) -> str:
        key = f"{m.group(2)}.{m.group(3)}".upper()
        return cfg.package_constants.get(key, m.group(0))

    if cfg.package_constants:
        before = masked
        masked = _THREE_PART_REF.sub(constant, masked)
        masked = re.sub(r"(?<![\w$#.])([A-Za-z_][\w$#]*)\s*\.\s*([A-Za-z_][\w$#]*)\b(?!\s*[.(])",
                        lambda m: cfg.package_constants.get(
                            f"{m.group(1)}.{m.group(2)}".upper(), m.group(0)),
                        masked)
        if masked != before:
            masked = _fold_int_math(masked)

    # Explicit user-supplied replacements win over the generic naming rules.
    def explicit(m: re.Match) -> str:
        target = lookup_function(cfg, m.group(1))
        return target if target else m.group(0)

    if cfg.function_map:
        masked = _ANY_CALL.sub(explicit, masked)

    def three_call(m: re.Match) -> str:
        schema, pkg, proc = m.group(1), m.group(2), m.group(3)
        return f"{cfg.pg_schema(schema)}.{pkg.lower()}_{proc.lower()}"

    masked = _THREE_PART_CALL.sub(three_call, masked)

    def two_call(m: re.Match) -> str:
        pkg, proc = m.group(1), m.group(2)
        if pkg.lower() not in pkgs:
            return m.group(0)
        return f"{cfg.pg_schema(default_schema)}.{pkg.lower()}_{proc.lower()}"

    masked = _TWO_PART_CALL.sub(two_call, masked)

    for m in _THREE_PART_REF.finditer(masked):
        if m.group(2).lower() in pkgs:
            notes.add("WARN", "package-variable", m.group(0),
                      "Package-level constant/variable reference - PostgreSQL packages do not "
                      "exist; replace with a function, a lookup table or a literal, or add it "
                      "to target.package_constants.")
    return masked
