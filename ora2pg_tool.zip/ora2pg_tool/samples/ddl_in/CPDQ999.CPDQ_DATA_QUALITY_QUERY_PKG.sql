CREATE OR REPLACE PACKAGE BODY CPDQ999.CPDQ_DATA_QUALITY_QUERY_PKG AS

    schemaName  CONSTANT VARCHAR2(30)  := 'CPDQ999';
    procName    CONSTANT VARCHAR2(100) := 'Data Quality Queries';

    FUNCTION Store_One_Column_Detail(columnNumber  IN  NUMBER,
                                     columnText    IN  VARCHAR2,
                                     entityCode    IN  VARCHAR2,
                                     queryId       IN  NUMBER,
                                     lineId        IN  NUMBER)
        RETURN NUMBER
    IS
    BEGIN
        INSERT INTO CPDQ.PROCEDURE_LINE_COLUMN
        (
            STORED_PROCEDURE_ID,
            LINE_ID,
            COLUMN_ID,
            COLUMN_X
        )
        VALUES
        (
            queryId,
            lineId,
            columnNumber,
            SUBSTR(columnText, 1, 200)
        );

        RETURN 0;

    EXCEPTION
        WHEN OTHERS THEN
            CPDC999.Rmdpk_Error_Log_Util.Log_Error(schemaName, procName,
                'CPDQ_DATA_QUALITY_QUERY_PKG.store_one_column_detail',
                'Error inserting data into CPDQ.PROCEDURE_LINE_COLUMN' ||
                ' procedure=' || queryId || ' entity=' || entityCode ||
                ' line=' || lineId || ' column=' || columnNumber,
                SQLCODE, SQLERRM);
            RETURN -1;
    END Store_One_Column_Detail;


    PROCEDURE Cpdq_Mlc_Pfg_Sap_Ne(lifeCycleCode IN  VARCHAR2,
                                  queryId       IN  NUMBER,
                                  returnCode    OUT NUMBER)
    IS
        lineId        NUMBER := 0;
        severity      NUMBER(1) := 3;
        reportLine    VARCHAR2(20);
        messageText   VARCHAR2(4000);
        v_now         DATE;

        CURSOR sCur IS
            SELECT m.CODE,
                   m.MATERIAL_TYPE_CODE,
                   NVL(p.PLANT_ID, 0)  AS PLANT_ID,
                   DECODE(m.STATUS, 'A', 'ACTIVE', 'I', 'INACTIVE', 'UNKNOWN') AS STATUS_TEXT
              FROM CPDQ999.MATERIAL m,
                   CPDQ999.PLANT    p,
                   CPDQ999.LIFECYCLE l
             WHERE m.PLANT_ID    = p.PLANT_ID(+)
               AND m.LIFECYCLE_C = l.LIFECYCLE_C(+)
               AND m.LIFECYCLE_C = lifeCycleCode
               AND ROWNUM <= 1000;
    BEGIN
        returnCode := 0;
        v_now      := SYSDATE;

        CPDC999.Rmdpk_Process_Log_Util.Log_Message(schemaName, procName,
            'Cpdq_Mlc_Pfg_Sap_Ne', 'Starting run for lifecycle ' || lifeCycleCode);

        FOR sCur IN sCur LOOP
            lineId     := lineId + 1;
            reportLine := 'LINE-' || TO_CHAR(lineId);
            messageText := 'Material ' || sCur.CODE || ' in plant ' || sCur.PLANT_ID;

            BEGIN
                INSERT INTO CPDQ.PROCEDURE_LINE
                (
                    STORED_PROCEDURE_ID,
                    LINE_ID,
                    LIFECYCLE_C,
                    REPORT_LINE_C,
                    SEVERITY_N,
                    REPORT_DESCRIPTION_X,
                    MESSAGE_X,
                    PROCESSED_C
                )
                VALUES
                (
                    queryId,
                    lineId,
                    lifeCycleCode,
                    reportLine,
                    severity,
                    'Missing PFG/SAP assignment',
                    messageText,
                    'N'
                );
            EXCEPTION
                WHEN OTHERS THEN
                    CPDC999.Rmdpk_Error_Log_Util.Log_Error(schemaName, procName,
                        'Inserting report lines',
                        'Error while trying to insert data for material ' || sCur.CODE ||
                        ' into PROCEDURE_LINE table', SQLCODE, SQLERRM);
                    returnCode := -1;
                    RETURN;
            END;

            IF Cpdq999.Cpdq_Data_Quality_Query_Pkg.Store_One_Column_Detail(
                            1,
                            sCur.MATERIAL_TYPE_CODE,
                            sCur.CODE,
                            queryId,
                            lineId) != 0 THEN
                returnCode := -2;
                RETURN;
            END IF;
        END LOOP;

        CPDC999.Rmdpk_Process_Log_Util.Log_Message(schemaName, procName,
            'Cpdq_Mlc_Pfg_Sap_Ne', 'Completed with ' || lineId || ' lines');

    EXCEPTION
        WHEN OTHERS THEN
            CPDC999.Rmdpk_Error_Log_Util.Log_Error(schemaName, procName,
                'Cpdq_Mlc_Pfg_Sap_Ne', 'Unhandled failure', SQLCODE, SQLERRM);
            returnCode := -99;
    END Cpdq_Mlc_Pfg_Sap_Ne;

END CPDQ_DATA_QUALITY_QUERY_PKG;
/
