CREATE OR REPLACE PROCEDURE "CPDQ999"."CPDQ_MLC_PFG_SAP_NE_PG1" (
                lifeCycleCode   IN  VARCHAR2,
                queryId         IN  NUMBER,
                returnCode      OUT INTEGER) IS

    schemaName VARCHAR2(30) := 'CPDQ999';
    procName   VARCHAR2(30) := 'cpdq_mlc_pfg_sap_ne_pg1';
    severity   PLS_INTEGER  := 2;

    lineId     PLS_INTEGER  := 0;

    CURSOR SelectCur IS
        SELECT /*+ use_hash(m, x) */
            m.CODE,
            mn.NAME,
            'SAP PFG Code Does Not Agree With PGINet' AS MESSAGE,
            m.MATERIAL_STATUS_CODE,
            m.MATERIAL_TYPE_CODE,
            ms.SALE_ORGANIZATION_CODE || ' / ' || ms.DISTRIBUTION_CHANNEL_CODE AS sale_org,
            p.GLOBE_CODE AS PLANT_ID,
            p.NAME AS PLANT_NAME,
            gsm.RCPRC AS SAP_PFG,
            rel.ITEM_GRP_C AS PGI_PFG
          FROM V_MATERIAL m,
               V_MATERIAL_NAME mn,
               V_MATERIAL_SALE ms,
               GLB_RGTT_MFOR gsm,
               V_PLANT p,
               NPPC_GLOBE_MATERIAL_XREF x,
               PACKAGED_GOOD_ITEM_GRP_REL rel
         WHERE m.DELETION_DATE IS NULL
           AND m.MAT_REC_OWNER_CODE = 'US'
           AND m.MATERIAL_STATUS_CODE IN ('Z2', 'Z3')
           AND NVL(ms.MAT_SALE_STATUS_CODE, ' ') IN (' ', 'ZX')
           AND TO_NUMBER(m.CODE) NOT IN (SELECT DISTINCT TO_NUMBER(EXCEPTION_ID)
                                           FROM REPORT_EXCEPTION
                                          WHERE REPORT_ID = 'CPDQ_MLC_PFG_SAP_NE_PG1')
           AND m.CODE = mn.MATERIAL_CODE
           AND mn.DELETION_DATE IS NULL
           AND ms.SALE_ORGANIZATION_CODE IN ('US53')
           AND ms.MATERIAL_CODE = m.MATERIAL_CODE
           AND ms.DELETION_DATE IS NULL
           AND mn.LANGUAGE_CODE = 'E'
           AND ms.MATERIAL_CODE = gsm.MATNR
           AND gsm.WERKS = p.GLOBE_CODE
           AND p.DELETION_DATE IS NULL
           AND p.COMPANY_CODE = 'US29'
           AND TO_NUMBER(mn.MATERIAL_CODE) = x.GLOBE_MATERIAL_N
           AND x.NPPC_ID = rel.ITEM_ID
           AND rel.ITEM_GRP_ID = x.ITEM_GRP_ID
           AND rel.ITEM_GRP_C != gsm.RCPRC
         ORDER BY m.CODE, sale_org;

-- Main body of procedure
BEGIN

    FOR sCur IN SelectCur LOOP
        lineId := lineId + 1;

        BEGIN

            INSERT INTO CPDQ.PROCEDURE_LINE (
                STORED_PROCEDURE_ID,
                LINE_ID,
                LIFECYCLE_C,
                REPORT_LINE_C,
                SEVERITY_N,
                REPORT_DESCRIPTION_X,
                MESSAGE_X,
                PROCESSED_C)
            VALUES (queryId,
                    lineId,
                    lifeCycleCode,
                    sCur.CODE,
                    severity,
                    sCur.NAME,
                    sCur.MESSAGE,
                    NULL);

        EXCEPTION
            WHEN OTHERS THEN
                CPDC999.Rmdpk_Error_Log_Util.Log_Error(schemaName, procName, 'Inserting report lines',
                        'Error while trying to insert data for material ' || sCur.CODE ||
                        ' into PROCEDURE_LINE table', SQLCODE, SQLERRM);
                returnCode := -1;
                RETURN;
        END;

        BEGIN

            IF Cpdq999.Cpdq_Data_Quality_Query_Pkg.Store_One_Column_Detail(
                            CPDQ999.Cpdqpk_Report.firstAdditionalColumn,
                            sCur.MATERIAL_TYPE_CODE,
                            sCur.CODE,
                            queryId,
                            lineId) != 0 THEN
                returnCode := -2;
                RETURN;
            END IF;

            IF Cpdq999.Cpdq_Data_Quality_Query_Pkg.Store_One_Column_Detail(
                            CPDQ999.Cpdqpk_Report.firstAdditionalColumn + 1,
                            sCur.MATERIAL_STATUS_CODE,
                            sCur.CODE,
                            queryId,
                            lineId) != 0 THEN
                returnCode := -3;
                RETURN;
            END IF;

            IF Cpdq999.Cpdq_Data_Quality_Query_Pkg.Store_One_Column_Detail(
                            CPDQ999.Cpdqpk_Report.firstAdditionalColumn + 2,
                            sCur.PLANT_ID,
                            sCur.CODE,
                            queryId,
                            lineId) != 0 THEN
                returnCode := -4;
                RETURN;
            END IF;

            IF Cpdq999.Cpdq_Data_Quality_Query_Pkg.Store_One_Column_Detail(
                            CPDQ999.Cpdqpk_Report.firstAdditionalColumn + 3,
                            sCur.PLANT_NAME,
                            sCur.CODE,
                            queryId,
                            lineId) != 0 THEN
                returnCode := -5;
                RETURN;
            END IF;

            IF Cpdq999.Cpdq_Data_Quality_Query_Pkg.Store_One_Column_Detail(
                            CPDQ999.Cpdqpk_Report.firstAdditionalColumn + 4,
                            sCur.SAP_PFG,
                            sCur.CODE,
                            queryId,
                            lineId) != 0 THEN
                returnCode := -6;
                RETURN;
            END IF;

            IF Cpdq999.Cpdq_Data_Quality_Query_Pkg.Store_One_Column_Detail(
                            CPDQ999.Cpdqpk_Report.firstAdditionalColumn + 5,
                            sCur.PGI_PFG,
                            sCur.CODE,
                            queryId,
                            lineId) != 0 THEN
                returnCode := -7;
                RETURN;
            END IF;

        EXCEPTION
            WHEN OTHERS THEN
                CPDC999.Rmdpk_Error_Log_Util.Log_Error(schemaName, procName, 'Inserting report lines',
                        'Error while trying to insert data for material ' || sCur.CODE ||
                        ' into PROCEDURE_LINE_COLUMN table', SQLCODE, SQLERRM);
                returnCode := -20;
                RETURN;
        END;

    END LOOP;

    COMMIT;

    returnCode := 0;

EXCEPTION
    WHEN OTHERS THEN
        CPDC999.Rmdpk_Error_Log_Util.Log_Error(schemaName, procName, 'Top level exception',
                'Error not caught by exception handling in main loop.', SQLCODE, SQLERRM);
        returnCode := -30;
END cpdq_mlc_pfg_sap_ne_pg1;
/
