CREATE OR REPLACE PROCEDURE CPDQ999.CPDQ_CLC_BRKR_LNK_MLTRY_CUST (
                lifeCycleCode IN  VARCHAR2,
                queryId       IN  NUMBER,
                returnCode    OUT INTEGER) IS

    schemaName VARCHAR2(30) := 'CPDQ999';
    procName   VARCHAR2(30) := 'cpdq_clc_brkr_lnk_mltry_cust';
    lineId     PLS_INTEGER  := 0;

    -- Nested subprogram: PostgreSQL has no nested functions, so this must be
    -- lifted out into a standalone function.
    FUNCTION Store_One_Column_Detail(columnNumber IN NUMBER,
                                     columnText   IN VARCHAR2,
                                     queryId      IN NUMBER,
                                     lineId       IN NUMBER)
        RETURN NUMBER
    IS
    BEGIN
        INSERT INTO CPDQ.PROCEDURE_LINE_COLUMN
            (STORED_PROCEDURE_ID, LINE_ID, COLUMN_ID, COLUMN_X)
        VALUES (queryId, lineId, columnNumber, SUBSTR(columnText, 1, 200));
        RETURN 0;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN -1;
    END Store_One_Column_Detail;

    -- (+) alongside a NOT IN (SELECT ...) subquery that itself contains OR.
    CURSOR SelectCur IS
        SELECT csd.CUSTOMER_CODE, c.NAME, b.BROKER_CODE
          FROM V_CUSTOMER_SITE_DTL csd,
               V_CUSTOMER c,
               V_BROKER b
         WHERE csd.CUSTOMER_CODE = c.CUSTOMER_CODE
           AND csd.BROKER_ID = b.BROKER_ID(+)
           AND csd.CUSTOMER_CODE NOT IN (SELECT csd2.CUSTOMER_CODE
                                           FROM V_CUSTOMER_SITE_DTL csd2
                                          WHERE csd2.MILITARY_FLAG = 'Y'
                                             OR csd2.STATUS = 'X')
           AND c.DELETION_DATE IS NULL;
BEGIN
    FOR sCur IN SelectCur LOOP
        lineId := lineId + 1;

        IF Store_One_Column_Detail(1, sCur.BROKER_CODE, queryId, lineId) != 0 THEN
            returnCode := -2;
            RETURN;
        END IF;
    END LOOP;

    returnCode := 0;
END CPDQ_CLC_BRKR_LNK_MLTRY_CUST;
/
