CREATE OR REPLACE PROCEDURE CPDQ999.OUTER_JOIN_CASES (
                queryId    IN  NUMBER,
                returnCode OUT INTEGER) IS

    CURSOR GoodCur IS
        SELECT c.CODE, cpf.CUSTOMER_CODE, p.NAME
          FROM CUSTOMER c,
               CUSTOMER_PROFILE cpf,
               PLANT p
         WHERE c.CODE = cpf.CUSTOMER_CODE(+)
           AND c.PLANT_ID = p.PLANT_ID(+)
           AND c.STATUS = 'A';

    -- Not mechanically rewritable: (+) on both sides of one predicate.
    CURSOR BadCur IS
        SELECT c.CODE, cpf.CUSTOMER_CODE
          FROM CUSTOMER c,
               CUSTOMER_PROFILE cpf
         WHERE c.CODE(+) = cpf.CUSTOMER_CODE(+)
           AND c.STATUS = 'A';

    -- Not mechanically rewritable: (+) inside an OR.
    CURSOR OrCur IS
        SELECT c.CODE, cpf.CUSTOMER_CODE
          FROM CUSTOMER c,
               CUSTOMER_PROFILE cpf
         WHERE (c.CODE = cpf.CUSTOMER_CODE(+) OR c.ALT_CODE = cpf.CUSTOMER_CODE(+))
           AND c.STATUS = 'A';

    -- Parenthesised group of AND'ed outer-join predicates.
    CURSOR GroupCur IS
        SELECT c.CODE, cpf.CUSTOMER_CODE
          FROM CUSTOMER c,
               CUSTOMER_PROFILE cpf
         WHERE (c.CODE = cpf.CUSTOMER_CODE(+) AND c.ORG = cpf.ORG(+))
           AND c.STATUS = 'A';
BEGIN
    returnCode := 0;
END OUTER_JOIN_CASES;
/
