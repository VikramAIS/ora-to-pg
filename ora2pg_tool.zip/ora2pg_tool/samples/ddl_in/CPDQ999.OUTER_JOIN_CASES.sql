CREATE OR REPLACE PROCEDURE CPDQ999.OUTER_JOIN_CASES (
                queryId    IN  NUMBER,
                returnCode OUT INTEGER) IS

    -- 1. simple: two optional tables, one driver
    CURSOR GoodCur IS
        SELECT c.CODE, cpf.CUSTOMER_CODE, p.NAME
          FROM CUSTOMER c,
               CUSTOMER_PROFILE cpf,
               PLANT p
         WHERE c.CODE = cpf.CUSTOMER_CODE(+)
           AND c.PLANT_ID = p.PLANT_ID(+)
           AND c.STATUS = 'A';

    -- 2. TWO driving tables + an outer join that references the first one.
    --    A comma here would make PostgreSQL reject the ON clause.
    CURSOR TwoBaseCur IS
        SELECT c.CODE, o.ORG_CODE, cpf.CUSTOMER_CODE
          FROM CUSTOMER c,
               ORGANISATION o,
               CUSTOMER_PROFILE cpf
         WHERE c.ORG_ID = o.ORG_ID
           AND c.CODE = cpf.CUSTOMER_CODE(+)
           AND cpf.ORG_CODE(+) = o.ORG_CODE
           AND c.STATUS = 'A';

    -- 3. chained: cpf is optional, and addr hangs off cpf
    CURSOR ChainCur IS
        SELECT c.CODE, cpf.CUSTOMER_CODE, a.CITY
          FROM CUSTOMER c,
               CUSTOMER_PROFILE cpf,
               ADDRESS a
         WHERE c.CODE = cpf.CUSTOMER_CODE(+)
           AND cpf.ADDRESS_ID = a.ADDRESS_ID(+)
           AND a.COUNTRY(+) = 'US';

    -- 4. schema-qualified, AS alias, and a filter-only (+) predicate
    CURSOR QualifiedCur IS
        SELECT m.CODE, gsm.RCPRC
          FROM CPDQ999.V_MATERIAL AS m,
               CPDQ999.GLB_RGTT_MFOR gsm
         WHERE m.CODE = gsm.MATNR(+)
           AND gsm.DELETION_DATE(+) IS NULL
           AND m.MAT_REC_OWNER_CODE = 'US';

    -- 5. inline view on the optional side
    CURSOR InlineCur IS
        SELECT c.CODE, t.TOTAL
          FROM CUSTOMER c,
               (SELECT CUSTOMER_CODE, SUM(AMT) AS TOTAL
                  FROM ORDERS GROUP BY CUSTOMER_CODE) t
         WHERE c.CODE = t.CUSTOMER_CODE(+);

    -- 6. parenthesised group of AND'ed outer-join predicates
    CURSOR GroupCur IS
        SELECT c.CODE, cpf.CUSTOMER_CODE
          FROM CUSTOMER c,
               CUSTOMER_PROFILE cpf
         WHERE (c.CODE = cpf.CUSTOMER_CODE(+) AND c.ORG = cpf.ORG(+))
           AND c.STATUS = 'A';

    -- 7. invalid in Oracle too (ORA-01719) - must be reported, not mangled
    CURSOR OrCur IS
        SELECT c.CODE, cpf.CUSTOMER_CODE
          FROM CUSTOMER c,
               CUSTOMER_PROFILE cpf
         WHERE (c.CODE = cpf.CUSTOMER_CODE(+) OR c.ALT_CODE = cpf.CUSTOMER_CODE(+))
           AND c.STATUS = 'A';
BEGIN
    returnCode := 0;
END OUTER_JOIN_CASES;
/
