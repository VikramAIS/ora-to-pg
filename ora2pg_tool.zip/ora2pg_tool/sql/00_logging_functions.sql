-- =====================================================================
-- Shared logging functions - deploy these ONCE before any converted
-- procedure. Every generated function calls them.
-- =====================================================================

CREATE OR REPLACE FUNCTION cpdc999.rmdpk_error_log_util_log_error(
    p_schema text,
    p_process text,
    p_function text,
    p_message text,
    p_errorcode text,
    p_errormessage text)
RETURNS void
LANGUAGE 'plpgsql'
COST 100
VOLATILE PARALLEL UNSAFE
AS $BODY$
BEGIN
    BEGIN
        INSERT INTO npcom.error_log
        (
            schema_na,
            process_na,
            function_na,
            message_x,
            error_c,
            error_message_x,
            user_id,
            create_ts
        )
        VALUES
        (
            left(p_schema, 30),
            left(p_process, 100),
            left(p_function, 100),
            left(p_message, 2000),
            coalesce(
                nullif(p_errorcode, ''),
                'NA'
            ),
            left(
                coalesce(
                    nullif(p_errormessage, ''),
                    'Unknown PostgreSQL error'
                ),
                1000
            ),
            left(current_user, 30),
            clock_timestamp()::timestamp
        );

    EXCEPTION
        WHEN OTHERS THEN
            RAISE WARNING
                'NPCOM error logging failed. SQLSTATE=%, error=%',
                SQLSTATE,
                SQLERRM;
    END;
END;
$BODY$;


CREATE OR REPLACE FUNCTION cpdc999.rmdpk_process_log_util_log_message(
    p_schema text,
    p_process text,
    p_function text,
    p_message text)
RETURNS void
LANGUAGE 'plpgsql'
COST 100
VOLATILE PARALLEL UNSAFE
AS $BODY$
BEGIN
    INSERT INTO npcom.process_log
    (
        process_log_id,
        schema_na,
        process_na,
        function_na,
        message_x,
        user_id,
        create_ts
    )
    VALUES
    (
        nextval('npcom.process_log_seq'),
        left(p_schema, 30),
        left(p_process, 100),
        left(p_function, 100),
        left(p_message, 2000),
        left(current_user, 30),
        clock_timestamp()::timestamp
    );
END;
$BODY$;
