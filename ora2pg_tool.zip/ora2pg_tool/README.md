# ora2pg_tool — Oracle PL/SQL → PostgreSQL PL/pgSQL converter

Batch-converts Oracle packages / procedures / functions (all 291 of them) into
PostgreSQL functions that follow **your** conventions: your data types, your
variable names, your logging functions and your target column widths.

Everything the converter does is driven by [config/mappings.yaml](config/mappings.yaml).
Nothing is hard-coded — paste your snapshots in there and re-run.

---

## Install

```powershell
cd d:\personal\rajareddy\ora2pg_tool
python -m pip install -r requirements.txt      # PyYAML (+ oracledb if pulling from Oracle)
```

## 1. List the objects to convert

Put your 291 names in [config/proc_list.txt](config/proc_list.txt), one per line:

```
CPDQ999.CPDQ_DATA_QUALITY_QUERY_PKG                             # whole package
CPDQ999.CPDQ_DATA_QUALITY_QUERY_PKG.STORE_ONE_COLUMN_DETAIL     # one subprogram
CPDQ999.MY_STANDALONE_PROC                                      # standalone
```

## 2. Convert

**Straight from Oracle** (reads `ALL_SOURCE`; needs only SELECT rights):

```powershell
$env:ORA_PASSWORD = "..."
python -m ora2pg convert `
    --proc-list config/proc_list.txt `
    --dsn "host:1521/SERVICE" --user CPDQ999 `
    --columns-csv config/pg_columns.csv `
    --out out --single-file
```

**Offline** (DDL already exported to `.sql` files named `SCHEMA.OBJECT.sql`):

```powershell
python -m ora2pg convert `
    --proc-list config/proc_list.txt `
    --source-dir ddl_in `
    --columns-csv config/pg_columns.csv `
    --out out --single-file
```

Output:

| Path | Contents |
|---|---|
| `out/oracle_ddl/` | the Oracle source that was actually converted |
| `out/postgres/` | one `.sql` per object, ready for review |
| `out/deploy_all.sql` | everything concatenated (`--single-file`) |
| `out/conversion_report.md` / `.csv` | every item that needs a human |

Deploy [sql/00_logging_functions.sql](sql/00_logging_functions.sql) **once** first —
every generated function calls those two.

## 3. Feed it your snapshots

| Your input | Where it goes |
|---|---|
| Data types per Oracle type | `datatypes.rules` |
| Data type per **variable name** | `variable_types.by_name` (wins over the declared type) |
| Naming convention (`_c`, `_n`, `_x`, `_id`, `_ts`) | `variable_types.by_suffix` |
| Oracle logging package → PostgreSQL function | `logging.handlers` |
| **Oracle routine → PostgreSQL function** | `functions.map` |
| Package constant → literal/expression | `target.package_constants` |
| Packages referenced from other objects | `target.known_packages` |
| Target column names + max lengths | `columns:` or `config/pg_columns.csv` |
| Oracle → PostgreSQL table/column renames | `table_renames` / `column_renames` |

### The function replacement list

By default a packaged call is renamed mechanically:
`CPDQ999.CPDQ_DATA_QUALITY_QUERY_PKG.STORE_ONE_COLUMN_DETAIL`
→ `cpdq999.cpdq_data_quality_query_pkg_store_one_column_detail`.

When that is not the name you actually deployed, override it in `functions.map`.
Keys match the **trailing** parts of the call, case-insensitively, most specific
first — so one entry covers qualified and unqualified call sites alike:

```yaml
functions:
  map:
    CPDQ999.CPDQ_DATA_QUALITY_QUERY_PKG.STORE_ONE_COLUMN_DETAIL: cpdq999.store_col   # exact
    CPDQ_DATA_QUALITY_QUERY_PKG.STORE_ONE_COLUMN_DETAIL: cpdq999.store_col           # any schema
    STORE_ONE_COLUMN_DETAIL: cpdq999.store_col                                       # unqualified too
```

Only the name is rewritten; arguments are left untouched. This list wins over
the generic naming rule and over `known_packages` resolution.

Have a raw column dump (like your screenshot)? Convert it to the CSV catalog:

```powershell
python -m ora2pg import-columns --input columns_dump.txt --out config/pg_columns.csv
```

---

## What it converts automatically

| Oracle | PostgreSQL |
|---|---|
| `PACKAGE BODY` | one function per subprogram, named `schema.package_subprogram` |
| `PROCEDURE p(x OUT NUMBER)` | `CREATE FUNCTION ... (OUT x integer) RETURNS integer` |
| `VARCHAR2/CLOB/CHAR` | `text` |
| `NUMBER(9)` / `NUMBER(18)` / `NUMBER(p,s)` / `NUMBER` | `integer` / `bigint` / `numeric(p,s)` / `numeric` |
| `DATE` | `timestamp` |
| Package-level constants | copied into each function's `DECLARE` |
| `CURSOR c IS SELECT` | `c CURSOR FOR SELECT` |
| `a.b(+) = c.d` | `LEFT OUTER JOIN ... ON ...` |
| `NVL`, `DECODE`, `SUBSTR(x,1,n)`, `SYSDATE`, `seq.NEXTVAL`, `MINUS`, `FROM DUAL` | `coalesce`, `CASE`, `left(x,n)`, `clock_timestamp()::timestamp`, `nextval('seq')`, `EXCEPT`, *(removed)* |
| `ADD_MONTHS` / `MONTHS_BETWEEN` / `LAST_DAY` | interval / `age()` / `date_trunc()` equivalents |
| `DBMS_OUTPUT.PUT_LINE` | `RAISE NOTICE` |
| `RAISE_APPLICATION_ERROR` | `RAISE EXCEPTION ... USING ERRCODE` |
| `EXECUTE IMMEDIATE` | `EXECUTE` |
| `PKG.PROC(...)` calls | `schema.pkg_proc(...)`, or whatever `functions.map` says |
| `PKG.CONSTANT` | the literal from `target.package_constants`, with `1 + 2` folded to `3` |
| Nested subprograms | hoisted to `schema.parent_nested`, calls re-pointed |
| `EXCEPTION WHEN OTHERS THEN` | `GET STACKED DIAGNOSTICS` + your `rmdpk_error_log_util_log_error` |
| `Log_Error(..., SQLCODE, SQLERRM)` | `PERFORM cpdc999.rmdpk_error_log_util_log_error(..., v_sqlstate, ...)` with `concat_ws` detail/hint/context and `left(...)` truncation |
| `INSERT`/`UPDATE` on a catalogued table | every character expression wrapped in `left(expr, <column length>)` |

Literals and comments are masked before any rewrite, so nothing inside a string
is ever modified.

## What it deliberately refuses to guess

These are reported in `conversion_report.md` **and** as `-- TODO[REVIEW]`
comments at the top of the generated file:

`COMMIT` / `ROLLBACK` / autonomous transactions · `DBMS_*` / `UTL_*` ·
`CONNECT BY` · `ROWNUM` · `BULK COLLECT` / `FORALL` · `SQL%ROWCOUNT` ·
user-defined exceptions · nested subprograms · collection/record types ·
`(+)` joins that are ambiguous (OR'ed, cyclic, multi-table) ·
`INSTR` / `NVL2` / `TRUNC` argument-order differences ·
package variables that lose session state.

## Recommended workflow for 291 objects

1. `python -m ora2pg extract ...` — snapshot the Oracle DDL into version control.
2. `python -m ora2pg convert ...` — generate + report.
3. Sort `out/conversion_report.csv` by severity; fix **ERROR** rows by adding
   rules to `mappings.yaml` and re-running (the tool is idempotent), or by hand.
4. Deploy `sql/00_logging_functions.sql`, then `out/deploy_all.sql` into a scratch
   database and let PostgreSQL's parser find the rest.
5. Run your regression tests comparing Oracle vs PostgreSQL result sets.

## Layout

```
ora2pg/
  masking.py       literal/comment masking - nothing else is allowed to see raw strings
  sqlutil.py       tokeniser, paren-aware splitting, keyword casing
  config.py        mappings.yaml + column CSV loader
  extractor.py     ALL_SOURCE / .sql file reader
  splitter.py      package body -> subprograms; header -> params/return
  transforms.py    data types, declarations, built-ins, packaged calls
  joins.py         (+) -> ANSI LEFT OUTER JOIN
  dml.py           column catalog -> left(expr, n)
  logging_calls.py Oracle log packages -> your PostgreSQL log functions
  converter.py     orchestration + DDL emission
  report.py        review report (md + csv)
  cli.py           command line
```
